package com.libtowns.simulation.control;

/**
 *
 * @author rkriebel
 */
public enum MessageRelevance {

    //highest
    ALERT(0),
    EVENT(1),
    INFO(2),
    DEBUG(3);
    //lowest
    
    int priority;
    
    private MessageRelevance(int pr){
        this.priority = pr;
    }
    
    public int getPriority(){
        return this.priority;
    }
}
