package com.libtowns.simulation.control;

import com.libtowns.data.parts.Cell;

/**
 *
 * @author rkriebel
 */
public class Message {

    public MessageRelevance mclass = MessageRelevance.INFO;
    public MessageType mtype = MessageType.UNDEFINED;
    public Cell cell = null;
    private String msg = "";
    public long tick;

    public Message() {
    }

    public Message(MessageRelevance type, String msg) {
        this.mclass = type;
        this.msg = msg;
    }

    public Message(MessageRelevance type, Cell cell, String msg) {
        this.mclass = type;
        this.cell = cell;
        this.msg = msg;
    }

    public String getMsg() {
        if (this.msg.length() == 0) {
            switch (mclass) {
                case INFO:
                    msg = "EMPTY INFO MESSAGE";
                    return msg;
                case EVENT:
                    msg = "EMPTY EVENT MESSAGE";
                    return msg;
                case ALERT:
                    msg = "EMPTY ALERT MESSAGE";
                    return msg;
                default:
                    msg = "EMPTY DEBUG MESSAGE";
                    return msg;
            }
        }
        return this.msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void print() {
        System.out.print(this.getFormatedMsg());
    }

    public String getFormatedMsg() {
        if (this.cell == null) {
            return String.format("%-5s : t: %10d : %-15s\n", this.mclass, this.tick, this.getMsg());
        } else {
            return String.format("%-5s : t: %10d : %-15s at : %d , %d\n", this.mclass, this.tick, this.getMsg(), cell.getX(), cell.getY());
        }
    }
}
