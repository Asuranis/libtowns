package com.libtowns.simulation.control;

import com.libtowns.data.parts.CellType;

/**
 *
 * @author rkriebel
 */
public class Command {
    public CommandType type;
    public String sarg;
    public int[] args;
    
    public void buildBuilding(int pos_x,int pos_y,CellType type){
        this.type = CommandType.BUILD_BUILDING;
        this.args = new int[3];
        this.args[0] = pos_x;
        this.args[1] = pos_y;
        this.args[2] = type.getCellID();
    }
    
    public void destroyBuilding(int pos_x,int pos_y,CellType type){
        this.type = CommandType.DESTROY_BUILDING;
        this.args = new int[3];
        this.args[0] = pos_x;
        this.args[1] = pos_y;
        this.args[2] = type.getCellID();
    }

    public void proceedCode(String code) {
        this.type = CommandType.CODE_COMMAND;
        this.sarg = code;
    }

    public void upgradeBuilding(int x, int y) {
        this.type = CommandType.UPGRADE_BUILDING;
        this.args = new int[2];
        this.args[0] = x;
        this.args[1] = y;
    }
    
}
