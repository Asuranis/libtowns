package com.libtowns.simulation.control;

/**
 *
 * @author rkriebel
 */
public enum CommandType {

    BUILD_BUILDING,
    UPGRADE_BUILDING,
    DESTROY_BUILDING,
    //
    TERRAFORM,
    //
    BUY_FROM_MARKET,
    SELL_TO_MARKET,    
    MARKET_TRIGGER_SET,
    //
    STOP_PRODUCTION,
    RUN_PRODUCTION,
    
    CODE_COMMAND;
}
