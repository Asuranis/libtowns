/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.libtowns.simulation.control;

/**
 *
 * @author rkriebel
 */
public enum MessageType {
    UNDEFINED,
    //
    RES_ON_CASTLE_MISSING,
    CASTLE_STOCK_FULL,
    //
    BUILDING_COMPLEDED,
    NO_SOURCE_FOUND;
    
}
