package com.libtowns.simulation.utils;

import com.libtowns.data.Map;
import com.libtowns.data.parts.Cell;
import com.libtowns.data.parts.CellType;
import java.util.Random;

/**
 *
 * @author rkriebel
 */
public class MapGenerator {

    Random rn;

    public Map generateMap(int size) {
        long seed = System.currentTimeMillis();
        return generateMap(size, seed);
    }

    public Map generateMap(int size, String sseed) {
        return generateMap(size, sseed.hashCode());
    }

    public Map generateMap(int size, long seed) {

        rn = new Random(seed);
        Map map = new Map(size, seed);

        long timestamp = System.currentTimeMillis();

        //map.printGrid();
        advanced(map);
        setCastle(map);
        checkAndMakePlayable(map);

        simulateMap(map);

        long runtime = System.currentTimeMillis() - timestamp;

        System.out.println("MapGenerator runtime: " + runtime + " ms");

        System.gc();

        return map;
    }

    private void advanced(Map map) {
        purge(map);
        riverGen(map);
        advancedSurfaceGenerator(map);
    }

    //surface generators
    private void advancedSurfaceGenerator(Map map) {
        float[][] altitude = PerlinGenerator.generate(rn,map.seed, map.size, map.size, 3);
        float[][] humidity = PerlinGenerator.generate(rn,map.seed, map.size, map.size, 4);
        float[][] nice = PerlinGenerator.generate(rn,map.seed, map.size, map.size, 4);
        float[][] random = PerlinGenerator.generate(rn,map.seed, map.size, map.size, 1);

        Cell cell;
        Cell pom_cell;

        for (int i = 0; i < map.size; i++) {
            for (int j = 0; j < map.size; j++) {

                //river edge altitude and humidity change
                for (int a = -2; a <= 2; a++) {
                    for (int b = -2; b <= 2; b++) {
                        pom_cell = map.getCell(i + a, j + b);
                        if (pom_cell != null) {
                            if (pom_cell.getCellType() == CellType.RIVER) {
                                altitude[i][j] -= 0.01f * (3 - Math.abs(a));
                                humidity[i][j] += 0.015f * (1 - Math.abs(a));
                                nice[i][j] -= 0.025f;
                            }
                        }
                    }
                }

                humidity[i][j] = (4 * humidity[i][j] + Math.abs(altitude[i][j] - 0.5f)) / 4;

                cell = map.getCell(i, j);

                //set tile types
                if (cell.getCellType() != CellType.RIVER) {

                    if (altitude[i][j] < 0.08f) {
                        if (nice[i][j] < 0.2) {
                            cell.recreate(CellType.SWAMP);
                        } else {
                            if (random[i][j] < 0.7f) {
                                cell.recreate(CellType.POND);
                            } else {
                                cell.recreate(CellType.FOREST);
                            }
                        }
                    } else if (altitude[i][j] < 0.2f) {
                        if (humidity[i][j] < 0.50f) {
                            if (nice[i][j] < 0.5) {
                                cell.recreate(CellType.SWAMP);
                            } else {
                                cell.recreate(CellType.FOREST);
                            }
                        } else if (random[i][j] < 0.33f) {
                            cell.recreate(CellType.SWAMP);
                        } else {
                            cell.recreate(CellType.POND);
                        }
                    } else if (altitude[i][j] < 0.45f) {
                        if (humidity[i][j] < 0.33f) {
                            if (random[i][j] < 0.995) {
                                cell.recreate(CellType.PLAINS);
                            } else {
                                cell.recreate(CellType.FIELD);
                            }
                        } else if (nice[i][j] < 0.3) {
                            cell.recreate(CellType.SWAMP);
                        } else {
                            cell.recreate(CellType.FOREST);
                        }
                    } else if (altitude[i][j] < 0.7f) {
                        if (humidity[i][j] < 0.75f) {
                            if (random[i][j] < 0.995f) {
                                cell.recreate(CellType.PLAINS);
                            } else {
                                cell.recreate(CellType.FIELD);
                            }
                        } else if (nice[i][j] < 0.3) {
                            cell.recreate(CellType.SWAMP);
                        } else {
                            cell.recreate(CellType.FOREST);
                        }
                    } else if (humidity[i][j] < 0.9f) {
                        if (random[i][j] < 0.7f) {
                            cell.recreate(CellType.QUARRY);
                        } else {
                            cell.recreate(CellType.ORE_MOUNT);
                        }
                    } else if (nice[i][j] < 0.4f) {
                        cell.recreate(CellType.SWAMP);
                    } else {
                        cell.recreate(CellType.FOREST);
                    }
                }
            }
        }

    }

    private void riverGen(Map map) {
        int pos_x = 0;
        int pos_y = rn.nextInt((int) (map.size * 0.8f)) + (int) (map.size * 0.1);

        int dir = 1;
        int last_dir = 1;

        int step = 0;
        int dir_c = 1;

        while (pos_x >= 0 && pos_x < map.size && pos_y >= 0 && pos_y < map.size) {


            if (step > 1 && rn.nextFloat() < 0.10f * dir_c) {
                dir_c = 1;
                int counter = 0;
                do {
                    dir = rn.nextInt(3);
                    counter++;
                } while (Math.abs(last_dir - dir) == 2 || (last_dir == dir && counter < 5));
                step = 0;
            } else {
                dir_c++;
            }

            map.setCell(pos_x, pos_y, CellType.RIVER, getRiverTileVariant(last_dir, dir));

            step++;
            last_dir = dir;

            switch (dir) {
                case 0:
                    pos_y--;
                    break;
                case 1:
                    pos_x++;
                    break;
                default:
                    pos_y++;
                    break;
            }
        }
    }

    private int getRiverTileVariant(int last_dir, int dir) {
        if (last_dir == 0 && dir == 0) {
            return 1;
        }
        if (last_dir == 0 && dir == 1) {
            return 5;
        }
        if (last_dir == 1 && dir == 0) {
            return 3;
        }
        if (last_dir == 1 && dir == 1) {
            return 0;
        }
        if (last_dir == 1 && dir == 2) {
            return 2;
        }
        if (last_dir == 2 && dir == 1) {
            return 4;
        }
        if (last_dir == 2 && dir == 2) {
            return 1;
        }
        return 0;
    }

    private void purge(Map map) {
        for (int i = 0; i < map.size; i++) {
            for (int j = 0; j < map.size; j++) {
                map.setCell(i, j, CellType.PLAINS);
            }
        }
    }

    private void setCastle(Map map) {
        Cell cell = null;
        int counter = 0;
        int pom_x = 1;
        int pom_y = 1;

        UUIntGenerator uig_X = new UUIntGenerator(map.size - 4, rn);
        UUIntGenerator uig_Y = new UUIntGenerator(map.size - 4, rn);


        pom_x = uig_X.getNext();
        do {
            counter++;

            pom_y = uig_Y.getNext();
            if (pom_y < 0) {
                uig_Y = new UUIntGenerator(map.size - 2, rn);
                pom_y = uig_Y.getNext();
                pom_x = uig_X.getNext();
            }

            if (pom_x < 0) {
                uig_X = new UUIntGenerator(map.size - 2, rn);
                uig_Y = new UUIntGenerator(map.size - 2, rn);
                pom_y = uig_Y.getNext();
                pom_x = uig_X.getNext();
            }

            cell = map.getCell(pom_x + 1, pom_y + 1);

        } while (cell.getCellType() == CellType.RIVER || cell.getCellType() == CellType.PLAINS || counter > Math.pow(map.area_size, 5));


        if (cell.getCellType() == CellType.RIVER) {
            uig_X = new UUIntGenerator(map.size, rn);
            uig_Y = new UUIntGenerator(map.size, rn);
            pom_x = uig_X.getNext();

            do {
                pom_y = uig_Y.getNext();
                if (pom_y < 0) {
                    uig_Y = new UUIntGenerator(map.size, rn);
                    pom_y = uig_Y.getNext();
                    pom_x = uig_X.getNext();
                }

                if (pom_x < 0) {
                    uig_X = new UUIntGenerator(map.size, rn);
                    pom_x = uig_X.getNext();
                }

                cell = map.getCell(pom_x, pom_y);
            } while (cell.getCellType() == CellType.PLAINS || cell.getCellType() == CellType.RIVER);



        }

        cell.recreate(CellType.CASTLE, 0);
        map.setCastle(cell);

    }

    private void simulateMap(Map map) {
        Cell cell;
        for (int i = 0; i < map.size; i++) {
            for (int j = 0; j < map.size; j++) {
                cell = map.getCell(i, j);
                cell.creationComplete();
            }
        }
    }

    private void checkAndMakePlayable(Map map) {
        //PLAINS, FOREST, POND, QUARRY, ORE_MOUNT;
        Cell cell;
        int count = map.getCountOfCellType(CellType.PLAINS);
        if (count > 6) {
            count = map.getCountOfCellType(CellType.POND);
            if (count < 1) {
                cell = map.getRandomCell(CellType.PLAINS);
                cell.recreate(CellType.POND);
                checkAndMakePlayable(map);
            }
            count = map.getCountOfCellType(CellType.ORE_MOUNT);
            if (count < 1) {
                cell = map.getRandomCell(CellType.PLAINS);
                cell.recreate(CellType.ORE_MOUNT);
                checkAndMakePlayable(map);
            }
            count = map.getCountOfCellType(CellType.QUARRY);
            if (count < 1) {
                cell = map.getRandomCell(CellType.PLAINS);
                cell.recreate(CellType.QUARRY);
                checkAndMakePlayable(map);
            }
            count = map.getCountOfCellType(CellType.FOREST);
            if (count < 2) {
                cell = map.getRandomCell(CellType.PLAINS);
                cell.recreate(CellType.FOREST);
                cell = map.getRandomCell(CellType.PLAINS);
                cell.recreate(CellType.FOREST);
                checkAndMakePlayable(map);
            }
        } else {
            count = map.getCountOfCellType(CellType.FOREST);
            if (count > 6) {
                cell = map.getRandomCell(CellType.FOREST);
                cell.recreate(CellType.PLAINS);
                cell = map.getRandomCell(CellType.FOREST);
                cell.recreate(CellType.PLAINS);
                checkAndMakePlayable(map);
            }
            count = map.getCountOfCellType(CellType.ORE_MOUNT);
            if (count > 3) {
                cell = map.getRandomCell(CellType.ORE_MOUNT);
                cell.recreate(CellType.PLAINS);
                checkAndMakePlayable(map);
            }
            count = map.getCountOfCellType(CellType.QUARRY);
            if (count > 3) {
                cell = map.getRandomCell(CellType.QUARRY);
                cell.recreate(CellType.PLAINS);
                checkAndMakePlayable(map);
            }
            count = map.getCountOfCellType(CellType.POND);
            if (count > 3) {
                cell = map.getRandomCell(CellType.POND);
                cell.recreate(CellType.PLAINS);
                checkAndMakePlayable(map);
            }
        }
    }
}
