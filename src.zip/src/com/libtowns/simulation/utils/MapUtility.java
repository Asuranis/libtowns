/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.libtowns.simulation.utils;

import com.libtowns.data.parts.Cell;
import com.libtowns.data.parts.CellType;

/**
 *
 * @author rkriebel
 */
public class MapUtility {

    public static void destroy(Cell cell) {
        if (cell.getCellType() != CellType.RIVER || cell.getCellType() != CellType.SWAMP) {
            switch (cell.getCellType()) {
                case POND:
                    cell.recreate(CellType.SWAMP, cell.getSubTypeID());
                case ORE_MOUNT:
                    cell.recreate(CellType.SWAMP);
                case QUARRY:
                    cell.recreate(CellType.SWAMP);
                default:
                    cell.recreate(CellType.PLAINS);
            }
            cell.freeBuild();
        }
    }
}
