/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.libtowns.simulation.utils;

import java.util.Random;

/**
 *
 * @author rkriebel
 */
public class UUIntGenerator {

    private final int max;
    private boolean[] numbers;
    private Random rn = null;
    private int counter;

    public UUIntGenerator(int max, Random rn) {
        this.max = max;
        this.numbers = new boolean[max];
        this.rn = rn;
    }

    public int getNext() {
        if (counter < max) {
            int ret = 0;
            boolean error = true;
            do {
                ret = rn.nextInt(max);

                if (!numbers[ret]) {
                    numbers[ret] = true;
                    error = false;
                    counter++;
                }
            } while (error);
            return ret;
        }
        return -10;
    }

    public void reset() {
        this.numbers = new boolean[max];
        this.counter = 0;
    }
}
