package com.libtowns.simulation.systems.parts;

/**
 *
 * @author rkriebel
 */
public enum NatureEventType {
    FIRE,
    DRY,
    WET,
    FOREST,
    MOUNT,
    ERODE;
}
