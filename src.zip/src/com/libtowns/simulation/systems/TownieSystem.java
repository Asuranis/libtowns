package com.libtowns.simulation.systems;

import com.libtowns.GlobalConstants;
import com.libtowns.data.Map;
import com.libtowns.data.parts.*;
import com.libtowns.simulation.Core;
import com.libtowns.simulation.control.MessageRelevance;
import com.libtowns.simulation.control.MessageType;
import com.libtowns.simulation.utils.MapUtility;

/**
 *
 * @author rkriebel
 */
public class TownieSystem {

    private final Map map;

    public TownieSystem(Map map) {
        this.map = map;
    }

    public void proceedTownies() {
        Townie townie;
        int size = this.map.getLtownie().size();
        for (int i = 0; i < size; i++) {
            townie = this.map.getLtownie().get(i);
            if (townie.getTstate() != TownieState.UNASSIGNED) {
                this.proceedTownie(townie);
            }
        }
    }

    public void proceedTownie(Townie townie) {

        switch (townie.getTclass()) {
            case CARRIER: {
                // <editor-fold defaultstate="collapsed" desc="CARRIER --- OK">
                switch (townie.getTstate()) {
                    case ASSIGNED: {
                        townie.decreaseTimer();
                        if (townie.getTimer() < 0) {
                            townie.setPos(map.getCastle());
                            if (getResourceFromCastle(townie)) {
                                Core.i().putMessage(MessageRelevance.DEBUG, "Resource obtained => move to target");
                                townie.setTstate(TownieState.MOVING_TO_TARGET);
                                townie.setGoalPos(townie.getTarget());
                            } else {
                                townie.setTstate(TownieState.WAITING_FOR_RESOURCES);
                                townie.setTimer(GlobalConstants.ticks_per_day / 4);
                                //put message #!#
                                //Core.getInstance().putMessage(null);
                                Core.i().putMessage(MessageRelevance.ALERT, "Missing res.: " + townie.getAmount_to_target() + " " + townie.getResource_to_target());

                            }
                        }
                        break;
                    }
                    case WAITING_FOR_RESOURCES: {
                        if (getResourceFromCastle(townie)) {
                            Core.i().putMessage(MessageRelevance.DEBUG, "Resource obtained => move to target");
                            townie.setTstate(TownieState.MOVING_TO_TARGET);
                            townie.setGoalPos(townie.getTarget());
                        } else {
                            townie.decreaseTimer();
                            if (townie.getTimer() < 0) {
                                Cell cell = townie.getTarget();
                                if (cell.getCellState() == CellState.WAITING_FOR_RESOURCE) {
                                    cell.setState(CellState.RECIEVED_RESOURCE);
                                } else if (cell.getCellState() == CellState.WAITING_FOR_UNKEEP) {
                                    cell.setState(CellState.RECIEVED_UNKEEP);
                                }
                                townie.disable();
                            }
                        }
                        break;
                    }
                    case MOVING_TO_TARGET: {
                        if (townie.isOnTarget()) {
                            Core.i().putMessage(MessageRelevance.DEBUG, "Townie CARRIER is on target");
                            if (townie.getAmount() > 0 && townie.getRes() != null) {

                                Cell cell = map.getCell(townie.getPosX(), townie.getPosY());
                                if (cell.canAcceptResource(townie.getResource_to_target())) {
                                    this.giveResourceToCell(townie);
                                } else {
                                    this.giveResourceToCastle(townie);
                                }
                                townie.setAmount(0);
                                townie.setRes(null);
                            }
                            if (townie.getAmount_to_origin() > 0) {
                                this.getResourceFromCell(townie);
                            }
                            townie.setGoalPos(townie.getOrigin());
                            townie.setTstate(TownieState.MOVING_TO_ORIGIN);
                        } else {
                            this.move(townie);
                        }
                        break;
                    }
                    case MOVING_TO_ORIGIN: {
                        if (townie.isOnTarget()) {
                            Core.i().putMessage(MessageRelevance.DEBUG, "Townie CARRIER is back on origin");
                            if (townie.getAmount() > 0 && townie.getRes() != null) {
                                this.giveResourceToCastle(townie);
                                townie.setAmount(0);
                                townie.setRes(null);

                            }
                            townie.disable();
                        } else {
                            this.move(townie);
                        }
                        break;
                    }
                }
            }//end of carrier
            break;
            // </editor-fold>

            case WORKER: {
                // <editor-fold defaultstate="collapsed" desc="WORKER--- OK">
                switch (townie.getTstate()) {
                    case ASSIGNED: {
                        townie.setPos(townie.getOrigin());
                        townie.setTstate(TownieState.MOVING_TO_TARGET);
                        townie.setGoalPos(townie.getTarget());

                        break;
                    }
                    case MOVING_TO_TARGET: {
                        if (townie.isOnTarget()) {
                            Core.i().putMessage(MessageRelevance.DEBUG, "Townie WORKER is on target");
                            StockSlot outstock = townie.getTarget().getOutputStock();
                            if (outstock != null) {
                                Core.i().putMessage(MessageRelevance.DEBUG, "Townie WORKER source stock exists");
                                if (outstock.getType() == townie.getResource_to_origin() && outstock.getAmount() > 0) {
                                    Core.i().putMessage(MessageRelevance.DEBUG, "Townie WORKER source type correct");
                                    townie.setTimer(CellConstants.getProducingTime(townie.getOrigin().getCellType()));
                                    townie.setTstate(TownieState.GATHER);
                                    return;
                                }
                            }
                            Core.i().putMessage(MessageRelevance.DEBUG, "Townie WORKER source is empty");
                            townie.setGoalPos(townie.getOrigin());
                            townie.setTstate(TownieState.MOVING_TO_ORIGIN);
                        } else {
                            this.move(townie);
                        }
                        break;
                    }
                    case GATHER:
                        townie.decreaseTimer();
                        if (townie.getTimer() < 0) {
                            this.getResourceFromCell(townie);
                            Core.i().putMessage(MessageRelevance.DEBUG, townie.getAmount() + " " + townie.getRes() + " was gathered from source " + townie.getTarget().getCellType());
                            Cell cell = map.getCell(townie.getPosX(), townie.getPosX());
                            if (cell != null) {
                                StockSlot outstock = cell.getOutputStock();
                                if (outstock != null) {
                                    if (cell.getCellClass() == CellClass.SOURCE && outstock.getAmount() <= 0) {
                                        MapUtility.destroy(cell);
                                    }
                                }
                            }
                            townie.setGoalPos(townie.getOrigin());
                            townie.setTstate(TownieState.MOVING_TO_ORIGIN);
                        }
                        break;
                    case MOVING_TO_ORIGIN: {
                        if (townie.isOnTarget()) {
                            Core.i().putMessage(MessageRelevance.DEBUG, "Townie WORKER is back on origin");
                            if (townie.getAmount() > 0 && townie.getRes() != null) {
                                this.giveResourceToCell(townie);
                                Cell cell = townie.getOrigin();
                                if (cell.getCellState() == CellState.WAITING_FOR_RESOURCE) {
                                    cell.setState(CellState.RECIEVED_RESOURCE);
                                    Core.i().putMessage(MessageRelevance.DEBUG, "Townie WORKER makes" + cell.getCellType() + " Lv. " + cell.getLevel() + " RECIEVED_RESOURCE");
                                }
                                townie.setAmount(0);
                                townie.setRes(null);
                            }
                            Core.i().putMessage(MessageRelevance.DEBUG, "Disabling WORKER");
                            townie.disable();
                        } else {
                            this.move(townie);
                        }
                        break;
                    }
                }
            }//end of worker
            break;
            // </editor-fold>

        }
    }

    private void move(Townie townie) {
        float posX = townie.getX() + townie.getSubX() / 100f;
        float posY = townie.getY() + townie.getSubY() / 100f;
        float targetX = townie.getGoal_X();
        float targetY = townie.getGoal_Y();

        int dir = -10;
        //  0/0   1/0   2/0
        //  0/1   1/1   2/1
        //  0/2   1/2   2/2
        //  0/3   1/3   2/3
        //  0/4   1/4   2/4

        //dir
        //   3
        // 2   0
        //   1
        if (posX < targetX) {
            dir = 0;
        } else if (posX > targetX) {
            dir = 2;
        } else if (posY < targetY) {
            dir = 1;
        } else if (posY > targetY) {
            dir = 3;
        }

        townie.moveTo(dir);
    }

    public Cell getNearestTile(Townie townie, CellType type) {
        Cell ret = null;

        for (int a = 1; a < this.map.size; a++) {
            for (int j = -a; j <= a; j++) {
                for (int i = -a; i <= a; i++) {
                    ret = map.getCell(townie.getPosX() + i, townie.getPosY() + j);
                    if (ret != null) {
                        if (ret.getTypeID()
                                == type.getCellID()) {
                            return ret;
                        }
                    }
                }
            }
        }

        return ret;
    }

    private void getResourceFromCell(Townie townie) {
        ResourceType type = townie.getResource_to_origin();
        if (type != null) {

            Cell cell = map.getCell(townie.getPosX(), townie.getPosY());
            StockSlot outstock = cell.getOutputStock();
            if (outstock != null) {

                if (outstock.getType() == type) {
                    townie.setRes(type);
                    if (outstock.getAmount() >= townie.getAmount_to_origin()) {
                        outstock.decAmount(townie.getAmount_to_origin());
                        townie.setAmount(townie.getAmount_to_origin());
                    } else {
                        townie.setAmount(outstock.getAmount());
                        outstock.setAmount(0);
                    }
                }

            } else {
                Core.i().putMessage(MessageRelevance.ALERT, "NO OUTPUT STOCK");
            }
        }
    }

    public void giveResourceToCell(Townie townie) {
        ResourceType type = townie.getRes();
        int amount = townie.getAmount();
        Cell cell = map.getCell(townie.getPosX(), townie.getPosY());
        StockSlot[] stock;

        Core.i().putMessage(MessageRelevance.DEBUG, "Townie try to give to " + cell.getCellType() + " Lv. " + cell.getLevel() + " " + amount + " " + type);

        if (townie.getTclass() == TownieClass.CARRIER) {
            if (cell.getCellState() == CellState.WAITING_FOR_UNKEEP) {
                stock = cell.getUnkeepStock();
                if (stock != null) {
                    for (int i = 0; i < stock.length; i++) {
                        if (stock[i].getType() == type) {
                            stock[i].addAmount(amount);
                            Core.i().putMessage(MessageRelevance.DEBUG, "Resource was gived to " + cell.getCellType() + " Lv. " + cell.getLevel() + " as unkeep: " + amount + " " + type);
                            cell.setState(CellState.RECIEVED_UNKEEP);
                            return;
                        }
                    }
                }
            }

            stock = cell.getInputStock();
            if (stock != null) {
                for (int i = 0; i < stock.length; i++) {
                    if (stock[i].getType() == type) {
                        stock[i].addAmount(amount);
                        Core.i().putMessage(MessageRelevance.DEBUG, "Resource was gived to " + cell.getCellType() + " Lv. " + cell.getLevel() + " as input: " + amount + " " + type);
                        cell.setState(CellState.RECIEVED_RESOURCE);
                        return;
                    }
                }
            }
        } else if (townie.getTclass() == TownieClass.WORKER) {
            StockSlot outstock = cell.getOutputStock();
            if (outstock != null) {
                if (outstock.getType() == type) {
                    outstock.addAmount(amount);
                    Core.i().putMessage(MessageRelevance.DEBUG, "Resource was gived to " + cell.getCellType() + " Lv. " + cell.getLevel() + " as product: " + amount + " " + type);
                    cell.setState(CellState.RECIEVED_RESOURCE);
                    return;
                }
            }
        }


        Core.i().putMessage(MessageRelevance.DEBUG, "Resource was gived to castle");
        map.getStock().giveResource(townie.getRes(), townie.getAmount());
        townie.setRes(null);
        townie.setAmount(0);
    }

    private boolean getResourceFromCastle(Townie townie) {
        ResourceType res = townie.getResource_to_target();
        int amount = townie.getAmount_to_target();

        if (res == ResourceType.ANY_FOOD) {
            ResourceType[] food = ResourceType.getFoodTypes();
            int counter = food.length * 5;
            do {
                res = food[Core.i().random.nextInt(food.length)];
                counter -= 1;
            } while (counter > 0 && amount > map.getStock().getAmount(res));

            if (amount <= map.getStock().getAmount(res)) {
                
                amount = map.getStock().getOutResource(res, amount);
                Core.i().putMessage(MessageRelevance.DEBUG, amount + " " + res + " => " + amount + " ANY_FOOD");
                if (amount > 0) {
                    townie.setAmount(amount);
                } else {
                    townie.setAmount(0);
                }
                townie.setRes(ResourceType.ANY_FOOD);
                return true;
            } else if (0 < map.getStock().getAmount(res)) {
                
                amount = map.getStock().getOutResource(res, map.getStock().getAmount(res));
                Core.i().putMessage(MessageRelevance.DEBUG, amount + " " + res + " => " + amount + " ANY_FOOD");
                if (amount > 0) {
                    townie.setAmount(amount);
                } else {
                    townie.setAmount(0);
                }
                townie.setRes(ResourceType.ANY_FOOD);

                return true;
            }
        } else if (amount <= map.getStock().getAmount(res)) {
            amount = map.getStock().getOutResource(res, amount);
            if (amount > 0) {
                townie.setAmount(amount);
            } else {
                townie.setAmount(0);
            }
            townie.setRes(res);
            return true;
        } else if (0 < map.getStock().getAmount(res)) {
            amount = map.getStock().getOutResource(res, map.getStock().getAmount(res));
            if (amount > 0) {
                townie.setAmount(amount);
            } else {
                townie.setAmount(0);
            }
            townie.setRes(res);
            return true;
        }
        return false;
    }

    private void giveResourceToCastle(Townie townie) {
        map.getStock().giveResource(townie.getRes(), townie.getAmount());
        Core.i().putMessage(MessageRelevance.DEBUG, "To castle was given: " + townie.getAmount() + " " + townie.getRes());
        if (map.getStock().isFull(townie.getRes())) {
            Core.i().putMessage(MessageRelevance.ALERT, MessageType.CASTLE_STOCK_FULL + " " + map.getStock().getAmount(townie.getRes()) + " " + townie.getRes());
        }
        townie.setRes(null);
        townie.setAmount(0);
    }
}
