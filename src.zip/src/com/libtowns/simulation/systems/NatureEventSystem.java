package com.libtowns.simulation.systems;

import com.libtowns.simulation.systems.parts.NatureEventType;
import com.libtowns.simulation.Core;
import com.libtowns.simulation.control.MessageRelevance;
import com.libtowns.simulation.utils.UUIntGenerator;
import com.libtowns.data.Map;
import com.libtowns.data.parts.Cell;
import com.libtowns.data.parts.ResourceType;
import com.libtowns.data.parts.CellClass;
import com.libtowns.data.parts.CellConstants;
import com.libtowns.data.parts.CellState;
import com.libtowns.data.parts.CellType;
import java.util.Random;

/**
 *
 * @author rkriebel
 */
public class NatureEventSystem {

    Map map;
    private final UUIntGenerator nature_event_random;
    private final Random rn;

    public NatureEventSystem(Map map, Random rn) {
        this.nature_event_random = new UUIntGenerator(50, rn);
        this.map = map;
        this.rn = rn;
    }

    public NatureEventType getNext() {
        NatureEventType event = NatureEventType.FOREST;
        if (rn.nextInt(8) == 0) {
            if (rn.nextInt(5) < 2) {
                return NatureEventType.ERODE;
            } else {
                return NatureEventType.MOUNT;
            }
        } else {
            switch (rn.nextInt(4)) {
                case 0:
                    return NatureEventType.FIRE;
                case 1:
                    return NatureEventType.DRY;
                case 2:
                    return NatureEventType.WET;
                case 3:
                    return NatureEventType.FOREST;
            }
        }
        return event;
    }

    public Cell natureEvent(NatureEventType event) {
        Cell cell = null;

        switch (event) {
            case FIRE:
                if (rn.nextInt(5) < 3) {;
                    cell = map.getRandomCell(CellType.FOREST);
                    if (cell != null) {
                        cell.recreate(CellType.PLAINS);
                    }
                } else {
                    cell = map.getRandomBuilding();
                    if (cell != null) {
                        Core.i().putMessage(MessageRelevance.DEBUG, "Building on Fire");
                        cell.recreate(CellType.PLAINS);
                    }

                }
                break;
            case FOREST:
                cell = map.getRandomCell(CellType.PLAINS);
                if (cell != null) {
                    cell.recreate(CellType.FOREST);
                }
                break;
            case DRY:
                if (rn.nextInt(5) != 0) {
                    if (rn.nextBoolean()) {
                        cell = map.getRandomCell(CellType.SWAMP);
                        if (cell != null) {
                            cell.recreate(CellType.PLAINS);
                        }
                    } else {
                        cell = map.getRandomCell(CellType.POND);
                        if (cell != null) {
                            cell.recreate(CellType.SWAMP);
                        }
                    }
                } else {
                    cell = map.getRandomCell(CellType.FOREST);
                    if (cell != null) {
                        cell.recreate(CellType.PLAINS);
                    }
                }
                break;
            case WET:
                if (rn.nextBoolean()) {
                    cell = map.getRandomCell(CellType.PLAINS);
                    if (cell != null) {
                        cell.recreate(CellType.SWAMP);
                    }
                } else {
                    cell = map.getRandomCell(CellType.SWAMP);
                    if (cell != null) {
                        cell.recreate(CellType.POND);
                    }
                }
                break;
            case ERODE:
                if (rn.nextBoolean()) {
                    cell = map.getRandomCell(CellType.QUARRY);
                } else {
                    cell = map.getRandomCell(CellType.ORE_MOUNT);
                }
                if (cell != null) {
                    if (rn.nextInt(3) == 0) {
                        cell.recreate(CellType.SWAMP);
                    } else {
                        cell.recreate(CellType.PLAINS);
                    }
                }
                break;

            case MOUNT:
                cell = map.getRandomCell(CellType.PLAINS);
                if (cell != null) {
                    if (rn.nextInt(3) == 0) {
                        cell.recreate(CellType.ORE_MOUNT);
                    } else {
                        cell.recreate(CellType.QUARRY);
                    }
                }
                break;
        }

        if (cell != null) {
            cell.freeBuild();
        }
        return cell;

    }

    public void proceedDay() {
        if (this.map.getLatest_nature_event() + 30 < this.map.getDay()) {
            int pom_NERN = nature_event_random.getNext();
            if (pom_NERN == 0) {
                NatureEventType evtype = getNext();
                natureEvent(evtype);
                this.map.setLatest_nature_event(this.map.getDay());
                nature_event_random.reset();
            }
        }
    }
}
