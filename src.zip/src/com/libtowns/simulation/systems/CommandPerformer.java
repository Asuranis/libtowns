package com.libtowns.simulation.systems;

import com.libtowns.data.Map;
import com.libtowns.data.parts.*;
import com.libtowns.simulation.Core;
import com.libtowns.simulation.control.Command;
import com.libtowns.simulation.control.MessageRelevance;

/**
 *
 * @author rkriebel
 */
public class CommandPerformer {

    public static boolean proceed(Map map, Command com) {
        switch (com.type) {
            case BUILD_BUILDING:
                map.setCell(com.args[0], com.args[1], CellType.getByID(com.args[2]), 0);
                Core.i().putMessage(MessageRelevance.DEBUG,
                        "Performing command " + com.type + " "
                        + CellType.getByID(com.args[2]) + " at: " + com.args[0] + "," + com.args[1]);
                return true;
            case DESTROY_BUILDING: {
                Cell bld = map.getCell((byte) com.args[0], (byte) com.args[1]);
                if (bld != null) {
                    if (bld.getCellType().isDestroyable()) {
                        map.setCell(com.args[0], com.args[1], CellType.PLAINS);
                        map.getCell(com.args[0], com.args[1]).freeBuild();
                    }
                }
                break;
            }

            case UPGRADE_BUILDING: {
                Cell bld = map.getCell((byte) com.args[0], (byte) com.args[1]);
                if (bld != null) {
                    // building can be upgradet do next level only if castle is on target level yet
                    if (bld.getCellType().isUpgradable() && bld.getLevel() + 1 <= map.getCastle().getLevel()) {
                        bld.upgrade();
                    }
                }
                break;
            }
            case CODE_COMMAND: {
                String str = com.sarg;
                if (str.equalsIgnoreCase("FEEDMEE")) {
                    Cell cell;
                    for (int i = 0; i < map.size; i++) {
                        for (int j = 0; j < map.size; j++) {
                            cell = map.getCell(i, j);
                            if (cell.getCellClass() == CellClass.GATHER_BUILDING || cell.getCellClass() == CellClass.FACTORY_BUILDING) {
                                StockSlot[] stock = cell.getUnkeepStock();
                                if (stock != null) {
                                    for (int k = 0; k < stock.length; k++) {
                                        if (stock[k].getType() == ResourceType.ANY_FOOD) {
                                            stock[k].addAmount(20);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (str.equalsIgnoreCase("KLONDIKE")) {
                    map.getStock().giveResource(ResourceType.COINS, 1000);
                }
                if (str.equalsIgnoreCase("FULLSTOCK")) {
                    for (int k = 1; k < ResourceType.getResourceTypes().length; k++) {
                        map.getStock().giveResource(ResourceType.getByID(k), 1000);
                    }
                }

                break;
            }
        }
        return false;
    }
}
