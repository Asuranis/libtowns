package com.libtowns.simulation.systems;

import com.libtowns.data.Map;
import com.libtowns.data.parts.*;
import com.libtowns.simulation.Core;
import com.libtowns.simulation.control.MessageRelevance;
import java.util.Random;

/**
 *
 * @author rkriebel
 */
public class CellSystem {

    private final Map map;
    private final Random random;

    public CellSystem(Map map, Random random) {
        this.map = map;
        this.random = random;
    }

    public void proceedCells() {
        Cell cell;
        for (int i = 0; i < map.size; i++) {
            for (int j = 0; j < map.size; j++) {
                cell = map.getCell(i, j);
                if (cell.getCellClass() != CellClass.NATURE || cell.getCellClass() != CellClass.SOURCE) {
                    this.proceedCell(cell);
                }
            }
        }
    }

    private void proceedCell(Cell cell) {
        if (cell.isIsActive()) {
            switch (cell.getCellClass()) {
                case BUILDING_LOT: {
                    // <editor-fold defaultstate="collapsed" desc="BUILDING_LOT --- for lvl_1 OK, maybe for upgrades too">
                    switch (cell.getCellState()) {
                        case NAPPING:
                            cell.decreaseTimer();
                            if (cell.getTimer() < 1) {
                                cell.setInputStock(CellConstants.getBuildingLotStock(cell.getCellType(), cell.getLevel()));
                                Core.i().putMessage(MessageRelevance.DEBUG, "Napping Building lot: " + cell.getCellType() + " Lv. " + cell.getLevel() + " timeout end. hasEnoughtToBuild: " + hasEnoughtToBuild(cell));
                                if (hasEnoughtToBuild(cell)) {
                                    cell.setState(CellState.UNDER_CONSTRUCTION);
                                    cell.setTimer(CellConstants.getBuildingLotTimeout(cell.getCellType(), cell.getLevel()));
                                    Core.i().putMessage(MessageRelevance.DEBUG, "Building lot: " + cell.getCellType() + " Lv. " + cell.getLevel() + " starts build");
                                    break;
                                } else {
                                    invokeRequestToBuild(cell);
                                    Core.i().putMessage(MessageRelevance.DEBUG, "Napping Building lot: " + cell.getCellType() + " Lv. " + cell.getLevel() + " has invoked request for resource");
                                }
                                cell.setState(CellState.WAITING_FOR_RESOURCE);
                            }
                            break;
                        case WAITING_FOR_RESOURCE:
                            break;
                        case RECIEVED_RESOURCE:
                            if (hasEnoughtToBuild(cell)) {
                                cell.setState(CellState.UNDER_CONSTRUCTION);
                                cell.setTimer(CellConstants.getBuildingLotTimeout(cell.getCellType(), cell.getLevel()));
                                Core.i().putMessage(MessageRelevance.DEBUG, "Building lot: " + cell.getCellType() + " Lv. " + cell.getLevel() + " starts build");

                                if (cell.getCellType() == CellType.FARM) {
                                    Core.i().putMessage(MessageRelevance.DEBUG, cell.getCellType() + " Lv. " + cell.getLevel() + " is seraching for " + CellType.PLAINS);
                                    Cell field = map.getNearestCellByType(cell, CellType.PLAINS);
                                    if (field == null) {
                                        Core.i().putMessage(MessageRelevance.DEBUG, "Not found: " + CellType.PLAINS);
                                    } else {
                                        field.recreate(CellType.FIELD);
                                        field.freeBuild();
                                    }
                                }
                            }
                            if (!cell.isTownieWorking()) {
                                invokeRequestToBuild(cell);
                                Core.i().putMessage(MessageRelevance.DEBUG, "Building lot: " + cell.getCellType() + " Lv. " + cell.getLevel() + " has invoked another request for resource");
                                cell.setState(CellState.WAITING_FOR_RESOURCE);
                            }
                            break;
                        case UNDER_CONSTRUCTION:
                            cell.decreaseTimer();
                            if (cell.getTimer() <= 0) {
                                cell.creationComplete();
                                if (cell.getCellType() == CellType.CASTLE) {
                                    map.getStock().setLevel(cell.getLevel());
                                }
                                if (cell.getCellType() == CellType.MARKET) {
                                    map.getMarket().setLevel(cell.getLevel());
                                }

                                Core.i().putMessage(MessageRelevance.INFO, cell, "Building lot: " + cell.getCellType() + " Lv. " + cell.getLevel() + " LVL " + cell.getLevel() + " complete");
                            }
                            break;
                    }
                    break;
                    //end of building lot
                }
                // </editor-fold>

                case GATHER_BUILDING: {
                    // <editor-fold defaultstate="collapsed" desc="GATHERING">
                    switch (cell.getCellState()) {
                        case WAITING_TO_EMPTY:

                            if (!this.isCellOutputStockFull(cell)) {
                                if (this.invokeRequestToGather(cell)) {
                                    Core.i().putMessage(MessageRelevance.DEBUG, "GATHERING:" + cell.getCellType() + " Lv. " + cell.getLevel() + " has invoked Request To GATHER " + cell.getOutputStock().getType());
                                    cell.setState(CellState.WAITING_FOR_RESOURCE);
                                } else {
                                    Core.i().putMessage(MessageRelevance.DEBUG, "NO RES ON MAP " + cell.getOutputStock().getType());
                                    cell.setTimer(CellConstants.getNapTime(cell.getCellType()));
                                    cell.setState(CellState.WAITING_FOR_MISSING_SOURCE);
                                }
                            }
                            break;
                        case WAITING_FOR_MISSING_SOURCE:
                            cell.decreaseTimer();
                            if (cell.getTimer() < 0) {
                                cell.setState(CellState.WAITING_TO_EMPTY);
                            }
                            break;
                        case WAITING_FOR_RESOURCE:
                            break;
                        case RECIEVED_RESOURCE:
                            if (this.isCellOutputStockFull(cell)) {
                                this.invokeRequestToEmptyOutputStock(cell);
                            }
                            cell.setState(CellState.NAPPING);
                            cell.setTimer(CellConstants.getNapTime(cell.getCellType()));
                            break;

                        case NAPPING:
                            cell.decreaseTimer();
                            if (cell.getTimer() < 1) {
                                if (cell.getUnkeepTimer() < 1) {
                                    if (hasEnoughtUnkeep(cell)) {
                                        consumeUnkeepResource(cell);
                                        cell.ressetUnkeepTimer();
                                        cell.setState(CellState.WAITING_TO_EMPTY);
                                    } else {
                                        if (!cell.isTownieWorking()) {
                                            invokeRequestToUnkeep(cell);
                                            cell.setState(CellState.WAITING_FOR_UNKEEP);
                                            Core.i().putMessage(MessageRelevance.DEBUG, cell.getCellType() + " Lv. " + cell.getLevel() + " WAITING_FOR_UNKEEP");
                                        }
                                    }
                                } else {
                                    cell.setState(CellState.WAITING_TO_EMPTY);
                                }
                            }
                            break;
                        case WAITING_FOR_UNKEEP:
                            break;
                        case RECIEVED_UNKEEP:
                            //Core.i().putMessage(MessageRelevance.DEBUG, cell.getCellType() + " Lv. " + cell.getLevel() + " RECIEVED_UNKEEP");
                            if (hasEnoughtUnkeep(cell)) {
                                consumeUnkeepResource(cell);
                                cell.ressetUnkeepTimer();
                                cell.setState(CellState.WAITING_TO_EMPTY);
                            } else {
                                if (!cell.isTownieWorking()) {
                                    invokeRequestToUnkeep(cell);
                                    cell.setState(CellState.WAITING_FOR_UNKEEP);
                                    Core.i().putMessage(MessageRelevance.DEBUG, cell.getCellType() + " Lv. " + cell.getLevel() + " WAITING_FOR_UNKEEP");
                                }
                            }
                            break;


                    }
                }//end of gathering
                break;
                // </editor-fold>

                case FACTORY_BUILDING: {
                    // <editor-fold defaultstate="collapsed" desc="FACTORY">

                    switch (cell.getCellState()) {
                        case WAITING_TO_EMPTY:
                            if (!isCellOutputStockFull(cell)) {
                                if (hasEnoughtToProduce(cell)) {
                                    cell.setState(CellState.PRODUCING_TIME);
                                    cell.setTimer(CellConstants.getProducingTime(cell.getCellType()));
                                    consumeInputResource(cell);
                                    Core.i().putMessage(MessageRelevance.DEBUG, cell.getCellType() + " Lv. " + cell.getLevel() + " GO TO PRODUCING TIME");
                                } else {
                                    if (!cell.isTownieWorking()) {
                                        this.invokeRequestToFactory(cell);
                                        cell.setState(CellState.WAITING_FOR_RESOURCE);
                                        Core.i().putMessage(MessageRelevance.DEBUG, "FACTORY: " + cell.getCellType() + " Lv. " + cell.getLevel() + " has invoked ResourceRequest To Produce");
                                    }
                                }
                            }
                            break;
                        case WAITING_FOR_RESOURCE:
                            break;
                        case RECIEVED_RESOURCE:
                            if (hasEnoughtToProduce(cell)) {
                                cell.setState(CellState.PRODUCING_TIME);
                                cell.setTimer(CellConstants.getProducingTime(cell.getCellType()));
                                consumeInputResource(cell);
                                Core.i().putMessage(MessageRelevance.DEBUG, cell.getCellType() + " Lv. " + cell.getLevel() + " GO TO PRODUCING TIME");
                            } else {
                                if (!cell.isTownieWorking()) {
                                    invokeRequestToFactory(cell);
                                    cell.setState(CellState.WAITING_FOR_RESOURCE);
                                    Core.i().putMessage(MessageRelevance.DEBUG, cell.getCellType() + " Lv. " + cell.getLevel() + " INVOKED ANOTHER ResourceRequest To Produce");
                                }
                            }
                            break;
                        case PRODUCING_TIME:
                            cell.decreaseTimer();
                            if (cell.getTimer() < 1) {
                                if (!isCellOutputStockFull(cell)) {
                                    giveProduct(cell);
                                }
                                if (!cell.isTownieWorking()) {
                                    invokeRequestToEmptyOutputStock(cell);
                                    cell.setState(CellState.NAPPING);
                                    cell.setTimer(CellConstants.getNapTime(cell.getCellType()));
                                }
                                Core.i().putMessage(MessageRelevance.DEBUG, cell.getCellType() + " Lv. " + cell.getLevel() + " PRODUCING TIME END");
                            }
                            break;
                        case NAPPING:
                            cell.decreaseTimer();
                            if (cell.getTimer() < 1) {
                                if (cell.getUnkeepTimer() < 1) {
                                    if (hasEnoughtUnkeep(cell)) {
                                        Core.i().putMessage(MessageRelevance.DEBUG, cell.getCellType() + " Lv. " + cell.getLevel() + " TIME FOR UNKEEP");
                                        consumeUnkeepResource(cell);
                                        cell.ressetUnkeepTimer();
                                        cell.setState(CellState.WAITING_TO_EMPTY);
                                    } else {
                                        if (!cell.isTownieWorking()) {
                                            invokeRequestToUnkeep(cell);
                                            cell.setState(CellState.WAITING_FOR_UNKEEP);
                                            Core.i().putMessage(MessageRelevance.DEBUG, cell.getCellType() + " Lv. " + cell.getLevel() + " WAITING_FOR_UNKEEP");
                                        }
                                    }
                                } else {
                                    cell.setState(CellState.WAITING_TO_EMPTY);
                                }
                            }
                            break;
                        case WAITING_FOR_UNKEEP:
                            break;
                        case RECIEVED_UNKEEP:
                            if (hasEnoughtUnkeep(cell)) {
                                consumeUnkeepResource(cell);
                                cell.ressetUnkeepTimer();
                                cell.setState(CellState.WAITING_TO_EMPTY);
                            } else {
                                if (!cell.isTownieWorking()) {
                                    invokeRequestToUnkeep(cell);
                                    cell.setState(CellState.WAITING_FOR_UNKEEP);
                                    Core.i().putMessage(MessageRelevance.DEBUG, cell.getCellType() + " Lv. " + cell.getLevel() + " WAITING_FOR_UNKEEP");
                                }
                            }
                            break;

                    }
                }//end of factory
                break;
                // </editor-fold>

            }
        }
    }

    private Townie callTownie() {
        Townie tow;
        for (int i = 0; i < map.getLtownie().size(); i++) {
            tow = map.getLtownie().get(i);
            if (tow.getTstate() == TownieState.UNASSIGNED) {
                Core.i().putMessage(MessageRelevance.DEBUG, "Townie called");
                return tow;
            }
        }

        Core.i().putMessage(MessageRelevance.DEBUG, "New Townie created");
        tow = new Townie();
        map.getLtownie().add(tow);
        return tow;
    }

    private void invokeRequestToUnkeep(Cell cell) {
        StockSlot[] unkeep = CellConstants.getUnkeepPrice(cell.getCellType(), cell.getLevel());
        StockSlot[] stock = cell.getUnkeepStock();

        int count = unkeep.length * 20;
        int nmb;

        do {
            nmb = this.random.nextInt(unkeep.length);
            if (unkeep[nmb].getType() != stock[nmb].getType()) {
                Core.i().putMessage(MessageRelevance.ALERT, "SOMETHING IS WERY WRONG : invokeResourceRequestToUnkeep");
                System.err.println("ERROR invoke unkeep");
                System.exit(1);
            } else if (unkeep[nmb].getAmount() > stock[nmb].getAmount()) {
                Townie tow = this.callTownie();
                tow.setOrigin(map.getCastle());
                tow.setTarget(cell);
                tow.setResource_to_target(unkeep[nmb].getType());
                tow.setAmount_to_target(unkeep[nmb].getAmount() - stock[nmb].getAmount());
                tow.setTclass(TownieClass.CARRIER);
                tow.setTstate(TownieState.ASSIGNED);

                cell.setTownieWorking(true);

                return;
            }

        } while (count > 0);

        Core.i().putMessage(MessageRelevance.ALERT, "SOMETHING WENT WRONG : invokeResourceRequestToUnkeep");
    }

    private void invokeRequestToFactory(Cell cell) {
        StockSlot[] price = CellConstants.getInputPrice(cell.getCellType(), cell.getLevel());
        StockSlot[] inputstock = cell.getInputStock();

        int count = price.length * 20;
        int nmb;
        do {
            nmb = this.random.nextInt(price.length);
            if (price[nmb].getType() == inputstock[nmb].getType()) {
                if (price[nmb].getAmount() > inputstock[nmb].getAmount()) {
                    Townie tow = this.callTownie();
                    tow.setOrigin(map.getCastle());
                    tow.setTarget(cell);
                    tow.setResource_to_target(price[nmb].getType());
                    tow.setAmount_to_target(price[nmb].getAmount() - inputstock[nmb].getAmount());
                    tow.setTclass(TownieClass.CARRIER);
                    tow.setTstate(TownieState.ASSIGNED);

                    cell.setTownieWorking(true);
                    return;
                }
            }

        } while (count > 0);

        Core.i().putMessage(MessageRelevance.ALERT, "SOMETHING WENT WRONG : invokeResourceRequestToProduce");
    }

    private void invokeRequestToBuild(Cell cell) {
        StockSlot[] pricetobuild = CellConstants.getBuildPrice(cell.getCellType(), cell.getLevel());
        StockSlot[] inputstock = cell.getInputStock();

        int count = pricetobuild.length * 20;
        int nmb;
        do {
            nmb = this.random.nextInt(pricetobuild.length);
            if (pricetobuild[nmb].getType() != inputstock[nmb].getType()) {
                Core.i().putMessage(MessageRelevance.ALERT, "SOMETHING IS WERY WRONG :  invokeResourceRequestToBuild");
                System.err.println("ERROR invoke to build");
                System.exit(1);
            } else if (pricetobuild[nmb].getAmount() > inputstock[nmb].getAmount()) {
                Townie tow = this.callTownie();
                tow.setOrigin(map.getCastle());
                tow.setTarget(cell);
                tow.setResource_to_target(pricetobuild[nmb].getType());
                tow.setAmount_to_target(pricetobuild[nmb].getAmount() - inputstock[nmb].getAmount());
                tow.setTclass(TownieClass.CARRIER);
                tow.setTstate(TownieState.ASSIGNED);

                cell.setTownieWorking(true);
                return;
            }

        } while (count > 0);
        Core.i().putMessage(MessageRelevance.ALERT, "SOMETHING WENT WRONG : invokeResourceRequestToBuild " + cell.getCellType() + " Lv. " + cell.getLevel() + " Enought:" + this.hasEnoughtToBuild(cell));
    }

    private boolean invokeRequestToGather(Cell cell) {
        Cell target = getNearestSourceCellToGather(cell);
        if (target != null) {
            Townie tow = this.callTownie();
            tow.setOrigin(cell);
            tow.setTarget(target);
            tow.setResource_to_origin(cell.getOutputStock().getType());
            tow.setAmount_to_origin(CellConstants.getOutputResource(cell.getCellType(), cell.getLevel()).getAmount());
            tow.setTclass(TownieClass.WORKER);
            tow.setTstate(TownieState.ASSIGNED);
            return true;
        }
        return false;
    }

    private void invokeRequestToEmptyOutputStock(Cell cell) {
        StockSlot stock = cell.getOutputStock();
        if (stock.getAmount() > 0) {
            Townie tow = this.callTownie();

            tow.setOrigin(map.getCastle());
            tow.setTarget(cell);

            tow.setResource_to_origin(stock.getType());
            tow.setAmount_to_origin(stock.getAmount());

            tow.setTimer(random.nextInt(50));
            tow.setTclass(TownieClass.CARRIER);
            tow.setTstate(TownieState.ASSIGNED);
            cell.setTownieWorking(true);
        }

    }

    private boolean hasEnoughtUnkeep(Cell cell) {
        StockSlot[] unkeep = CellConstants.getUnkeepPrice(cell.getCellType(), cell.getLevel());
        StockSlot[] stock = cell.getUnkeepStock();

        if (unkeep != null) {
            for (int i = 0; i < unkeep.length; i++) {
                if (unkeep[i].getType() != stock[i].getType()) {
                    Core.i().putMessage(MessageRelevance.ALERT, "SOMETHING IS WERY WRONG : hasEnoughtUnkeep");
                    System.err.println("ERROR enought unkeep");
                    System.exit(1);
                } else if (unkeep[i].getAmount() > stock[i].getAmount()) {
                    return false;
                }
            }
        }
        return true;

    }

    private boolean hasEnoughtToProduce(Cell cell) {
        StockSlot[] inptPrice = CellConstants.getInputPrice(cell.getCellType(), cell.getLevel());
        StockSlot[] inputstock = cell.getInputStock();

        if (inptPrice == null) {
            Core.i().putMessage(MessageRelevance.ALERT, cell.getCellType() + " Lv. " + cell.getLevel() + " NOT INPUT, PRODUCING FREE");
            return true;
        } else {
            boolean pom = true;
            for (int i = 0; i < inptPrice.length; i++) {
                if (inptPrice[i].getType() == inputstock[i].getType()) {
                    if (inptPrice[i].getAmount() > inputstock[i].getAmount()) {
                        return false;
                    }
                }
            }
            return true;
        }

    }

    private boolean hasEnoughtToBuild(Cell cell) {
        StockSlot[] pricetobuild = CellConstants.getBuildPrice(cell.getCellType(), cell.getLevel());
        StockSlot[] inputstock = cell.getInputStock();
        if (pricetobuild != null) {
            for (int i = 0; i < pricetobuild.length; i++) {
                if (pricetobuild[i].getType() != inputstock[i].getType()) {
                    Core.i().putMessage(MessageRelevance.ALERT, "SOMETHING IS WERY WRONG : hasEnoughtToProduce");
                    System.err.println("ERROR enought to build " + pricetobuild[i].getType() + " !=  " + inputstock[i].getType());
                    System.exit(1);
                } else if (pricetobuild[i].getAmount() > inputstock[i].getAmount()) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean isCellOutputStockFull(Cell cell) {
        return cell.getAmountInOutputStock() >= cell.capacity();
    }

    public void proceedDay() {
        Cell cell;
        for (int i = 0; i < map.size; i++) {
            for (int j = 0; j < map.size; j++) {
                cell = map.getCell(i, j);
                if ((cell.getCellClass() == CellClass.GATHER_BUILDING || cell.getCellClass() == CellClass.FACTORY_BUILDING) && cell.isIsActive()) {
                    map.getCell(i, j).decreaseUnkeepTimer();
                } else if (cell.getCellClass() == CellClass.SOURCE && cell.getCellType().isBuildable()) {
                    StockSlot stock = cell.getOutputStock();
                    if (stock.getAmount() < stock.getType().getMaxAmount() && stock.getAmount() > 10) {
                        stock.addAmount((int) (stock.getAmount() * 0.01f) + 1);
                    }
                }
            }
        }
    }

    private void giveProduct(Cell cell) {
        StockSlot output = CellConstants.getOutputResource(cell.getCellType(), cell.getLevel());
        StockSlot stock = cell.getOutputStock();

        if (stock.getType() == output.getType()) {
            stock.addAmount(output.getAmount());
        } else {
            Core.i().putMessage(MessageRelevance.ALERT, "SOMETHING IS WRONG :  giveProduct");
        }
    }

    private void consumeInputResource(Cell cell) {
        StockSlot[] price = CellConstants.getInputPrice(cell.getCellType(), cell.getLevel());
        StockSlot[] inputstock = cell.getInputStock();

        if (price != null) {
            for (int i = 0; i < price.length; i++) {
                Core.i().putMessage(MessageRelevance.DEBUG, cell.getCellType() + " Lv. " + cell.getLevel() + " consumed input: " + price[i].getType() + " " + price[i].getAmount());
                if (price[i].getType() != inputstock[i].getType()) {
                    Core.i().putMessage(MessageRelevance.ALERT, "SOMETHING IS WERY WRONG : consumeInputResource");
                    System.err.println("ERROR input consume");
                    System.exit(1);
                } else {
                    inputstock[i].decAmount(price[i].getAmount());
                }
            }
        }

    }

    private void consumeUnkeepResource(Cell cell) {
        StockSlot[] unkeep = CellConstants.getUnkeepPrice(cell.getCellType(), cell.getLevel());
        StockSlot[] stock = cell.getUnkeepStock();

        if (unkeep != null) {
            for (int i = 0; i < unkeep.length; i++) {
                Core.i().putMessage(MessageRelevance.DEBUG, stock[i].getType() + " " + stock[i].getAmount());
                if (unkeep[i].getType() != stock[i].getType()) {
                    Core.i().putMessage(MessageRelevance.ALERT, "SOMETHING IS WERY WRONG : consumeUnkeepResource");
                    System.err.println("ERROR unkeep consume");
                    System.exit(1);
                } else {
                    stock[i].decAmount(unkeep[i].getAmount());
                }
            }
        }
    }

    private Cell getNearestSourceCellToGather(Cell cell) {

        ResourceType type = cell.getOutputStock().getType();
        Cell ret;
        int X = cell.getX();
        int Y = cell.getY();

        Core.i().putMessage(MessageRelevance.DEBUG, cell.getCellType() + " Lv. " + cell.getLevel() + " is seraching for " + type + " source");

        for (int a = 1; a < this.map.size; a++) {
            for (int j = -a; j <= a; j++) {
                for (int i = -a; i <= a; i++) {
                    ret = map.getCell(X + i, Y + j);
                    if (ret != null) {
                        if (ret.getCellClass() == CellClass.SOURCE) {
                            StockSlot stock = ret.getOutputStock();
                            if (stock != null) {
                                if (stock.getType() == type && stock.getAmount() > 0) {
                                    Core.i().putMessage(MessageRelevance.DEBUG, "Found: " + type + " at: " + (X + i) + "," + (Y + j));
                                    return ret;
                                }
                            }
                        }
                    }
                }
            }
        }
        Core.i().putMessage(MessageRelevance.DEBUG, "Not found: " + type);
        return null;
    }
}
