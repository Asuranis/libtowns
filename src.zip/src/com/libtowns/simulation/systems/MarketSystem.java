package com.libtowns.simulation.systems;

import com.libtowns.data.parts.*;
import com.libtowns.simulation.Core;
import com.libtowns.simulation.control.MessageRelevance;
import java.util.Random;

/**
 * Created by robin on 26.10.15.
 */
public class MarketSystem {

    private Market market;
    private Stock stock;
    private final Random random;

    public MarketSystem(Market market, Stock stock, Random random) {
        this.market = market;
        this.stock = stock;
        this.random = random;

        for (int i = 1; i < ResourceType.getResourceTypes().length; i++) {
            MarketTrigger trg = market.getTrigger(ResourceType.getByID(i));
            trg.setMorethensell(80);
            trg.setSellactive(true);

            trg.setLessthenbuy(10);
            trg.setBuyactive(true);
        }
    }

    /*
     * Recount changes on market after day and proceeding triggers
     */
    public void proceedDay() {
        StockSlot[] market_slots = market.getStockSlots();
        MarketTrigger[] triggers = market.getTriggers();

        for (int i = 1; i < market_slots.length; i++) {
            ResourceType type = ResourceType.getByID(i);
            int targetamount = (int) (market.getCapacity() * type.getMarket_resource_change_coef());

            if (targetamount != market_slots[i].getAmount()) {
                if (random.nextFloat()< type.getMarket_resource_change_coef()) {
                    int changeamount = (int) Math.ceil(Math.pow(type.getMarket_resource_change_coef()+1, 2)) * market.getLevel();
                    int dif = Math.abs(targetamount - market_slots[i].getAmount());

                    System.out.println("dif " + type + " : " + dif);

                    if (changeamount > dif) {
                        dif = changeamount;
                    }
                    if (targetamount < market_slots[i].getAmount()) {
                        System.out.println("change " + type + " : -" + changeamount);
                        market_slots[i].decAmount(changeamount);
                    } else {
                        market_slots[i].addAmount(changeamount);
                        System.out.println("change " + type + " : " + changeamount);
                    }
                }
            }

            if (triggers[i].isBuyactive()) {
                if (triggers[i].getLessthenbuy() > stock.getAmount(type)) {
                    int amount = triggers[i].getLessthenbuy() - stock.getAmount(type);

                    Core.i().putMessage(MessageRelevance.INFO, "AutoBUY: " + type + " : " + amount + " | S: " + stock.getAmount(type) + " | M: " + market.getAmount(type));
                    for (int j = 0; j < amount; j++) {
                        if (this.canBuyResource(triggers[i].type)) {
                            buyFromMarket(type);
                        } else {
                            break;
                        }
                    }
                    Core.i().putMessage(MessageRelevance.INFO, "After AutoBUY: " + type + " : " + amount + " | S: " + stock.getAmount(type) + " | M: " + market.getAmount(type));
                }
            }

            if (triggers[i].isSellactive()) {
                if (triggers[i].getMorethensell() < stock.getAmount(type)) {
                    int amount = stock.getAmount(type) - triggers[i].getMorethensell();

                    Core.i().putMessage(MessageRelevance.INFO, "AutoSELL: " + type + " : " + amount + " | S: " + stock.getAmount(type) + " | M: " + market.getAmount(type));
                    for (int j = 0; j < amount; j++) {
                        if (this.canSellResource(triggers[i].type)) {
                            sellToMarket(type);
                        } else {
                            break;
                        }
                    }
                    Core.i().putMessage(MessageRelevance.INFO, "After AutoSELL: " + type + " : " + amount + " | S: " + stock.getAmount(type) + " | M: " + market.getAmount(type));

                }
            }
        }
    }

    public void sellToMarket(ResourceType type) {
        this.stock.getOutResource(type, 1);
        this.market.giveResource(type, 1);
        this.stock.giveResource(ResourceType.COINS, getSellToMarketPrice(type));
    }

    public void buyFromMarket(ResourceType type) {
        this.market.getOutResource(type, 1);
        this.stock.giveResource(type, 1);
        this.stock.getOutResource(ResourceType.COINS, getBuyFromMarketPrice(type));
    }

    public int getBuyFromMarketPrice(ResourceType type) {
        return (int) Math.ceil(type.getPrice() * 1.4f);
    }

    public int getSellToMarketPrice(ResourceType type) {
        return type.getPrice();
    }

    private boolean canBuyResource(ResourceType type) {
        if (getBuyFromMarketPrice(type) > this.stock.getAmount(ResourceType.COINS)) {
            return false;
        }
        if (this.market.getAmount(type) <= 0) {
            return false;
        }
        return true;
    }

    private boolean canSellResource(ResourceType type) {
        if (this.market.getAmount(type) >= this.market.getCapacity()) {
            return false;
        }
        return true;
    }
}
