/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.libtowns.data;

import java.io.Serializable;

/**
 *
 * @author rkriebel
 */
public class MapFile  implements Serializable{
    String name;
    long created;
    long lastplayed;
    Map map;
}
