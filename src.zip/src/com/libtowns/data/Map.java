package com.libtowns.data;

import com.libtowns.data.parts.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 * Created by robin on 23.10.15.
 *
 *
 */
public final class Map implements Serializable {

    public final int area_size;
    public final byte size;
    public final long seed;
    private Cell[][] grid;
    private final Stock stock = new Stock();
    private Cell castle_cell;
    private final Market market = new Market();
    private List<Townie> ltownie = new ArrayList();
    private long day = 0;
    private int tick = 0;
    private long latest_nature_event = 0;

    public Map(int size, long seed) {

        this.seed = seed;
        if (size < 6) {
            size = 6;
        }

        if (size > Byte.MAX_VALUE) {
            size = Byte.MAX_VALUE;
        }

        this.size = (byte) size;

        this.area_size = this.size * this.size;

        grid = new Cell[this.size][this.size];


        for (int i = 0; i < this.size; i++) {
            for (int j = 0; j < this.size; j++) {
                grid[i][j] = new Cell(i, j);
                grid[i][j].creationComplete();
            }
        }

        setCell(this.size / 2, this.size / 2, CellType.CASTLE, 0);
        Cell cell = getCell(this.size / 2, this.size / 2);
        cell.creationComplete();
        setCastle(cell);
    }

    public Cell getCell(int pos_x, int pos_y) {
        if (pos_x >= 0 && pos_y >= 0 && pos_x < this.size && pos_y < this.size) {
            return this.grid[pos_x][pos_y];
        } else {
            return null;
        }
    }

    public void setCell(int pos_x, int pos_y, CellType type) {
        Cell cell = this.getCell(pos_x, pos_y);
        if (cell != null) {
            cell.recreate(type);
        }
    }

    public void setCell(int pos_x, int pos_y, CellType type, int subType) {
        Cell cell = this.getCell(pos_x, pos_y);
        if (cell != null) {
            cell.recreate(type, subType);
        }
    }

    public long getDay() {
        return day;
    }

    public long getLatest_nature_event() {
        return latest_nature_event;
    }

    public Stock getStock() {
        if (this.castle_cell != null) {
            stock.setLevel(this.castle_cell.getLevel());
        }
        return stock;
    }

    public List<Townie> getLtownie() {
        return ltownie;
    }

    public Market getMarket() {
        return market;
    }

    public void printTileTypeGrid() {

        for (int j = 0; j < this.size; j++) {

            for (int i = 0; i < this.size; i++) {
                System.out.print(this.grid[i][j].getTypeID() + ":" + this.grid[i][j].getSubTypeID() + " ");
                if (this.grid[i][j].getTypeID() != 0 && this.grid[i][j].getSubTypeID() > 2) {
                    System.err.println("Tile error");
                }
            }
            System.out.println();
        }
    }

    public void printGrid() {
        String znak;
        for (int j = 0; j < this.size; j++) {

            for (int i = 0; i < this.size; i++) {
                switch (CellType.getByID(this.grid[i][j].getTypeID())) {
                    case PLAINS:
                        znak = "...";//∞∞
                        break;
                    case FOREST:
                        znak = "$$$";
                        break;
                    case POND:
                        znak = " O ";
                        break;
                    case FIELD:
                        znak = "|||";
                        break;
                    case RIVER:
                        znak = " ~ ";
                        break;
                    case SWAMP:
                        znak = " ¤ ";
                        break;
                    case ORE_MOUNT:
                        znak = "[@]";
                        break;
                    case QUARRY:
                        znak = "[#]";
                        break;
                    case CASTLE:
                        znak = "]^[";
                        break;
                    default:
                        znak = " ! ";
                        break;
                }
                System.out.print(znak);

            }
            System.out.println();
        }
    }

    public void printRiverGrid() {
        String znak;
        for (int j = 0; j < this.size; j++) {

            for (int i = 0; i < this.size; i++) {
                switch (CellType.getByID(this.grid[i][j].getTypeID())) {
                    case RIVER:
                        switch (this.grid[i][j].getSubTypeID()) {
                            case 0:
                                znak = "═";
                                break;
                            case 1:
                                znak = "║";
                                break;
                            case 2:
                                znak = "╗";
                                break;
                            case 3:
                                znak = "╝";
                                break;
                            case 4:
                                znak = "╚";
                                break;
                            case 5:
                                znak = "╔";
                                break;
                            default:
                                znak = "Err";
                                break;
                        }

                        break;
                    default:
                        znak = "░";
                        break;
                }
                System.out.print(znak);

            }
            System.out.println();
        }
    }

    public void printGridTownies() {
        String znak;
        for (int j = 0; j < this.size; j++) {

            for (int i = 0; i < this.size; i++) {
                znak = "";
                for (Townie tow : this.ltownie) {
                    if (tow.getPosX() == i && tow.getPosY() == j) {
                        znak = " ☺ ";
                    }
                }
                if (znak.length() < 3) {
                    znak = " , ";
                }

                System.out.print(znak);

            }
            System.out.println();
        }
    }

    public Cell getRandomCell(CellType type) {
        Cell cell = null;
        int count = 0;
        Random rn = new Random();

        for (int i = 0; i < this.size; i++) {
            for (int j = 0; j < this.size; j++) {
                if (grid[i][j].getTypeID() == type.getCellID()) {
                    count++;
                }
            }
        }

        if (count > 0) {
            do {
                cell = this.getCell(rn.nextInt(this.size), rn.nextInt(this.size));
                if (cell.getTypeID() == type.getCellID()) {
                    return cell;
                }
            } while (count > 0);

        }

        return cell;
    }

    public void setLatest_nature_event(long day) {
        this.latest_nature_event = day;
    }

    public void newDay() {
        this.day++;
    }

    public Cell getRandomBuilding() {
        Cell cell = null;
        int count = 0;
        Random rn = new Random();

        for (int i = 0; i < this.size; i++) {
            for (int j = 0; j < this.size; j++) {
                if (grid[i][j].getCellClass() != CellClass.NATURE && grid[i][j].getCellClass() != CellClass.SOURCE && CellType.getByID(grid[i][j].getTypeID()) != CellType.CASTLE) {
                    count++;
                }
            }
        }

        if (count > 0) {
            do {
                cell = this.getCell(rn.nextInt(this.size), rn.nextInt(this.size));
            } while (cell.getCellClass() != CellClass.NATURE && cell.getCellClass() != CellClass.SOURCE && CellType.getByID(cell.getTypeID()) == CellType.CASTLE);

        }

        return cell;
    }

    public Cell getCastle() {
        return castle_cell;
    }

    public void setCastle(Cell tile) {
        this.castle_cell = tile;
    }

    public int getTick() {
        return tick;
    }

    public void setTick(int tick) {
        this.tick = tick;
    }

    public StockSlot[] getMapResourcesSum() {
        StockSlot[] ret = new StockSlot[ResourceType.getResourceTypes().length];

        for (int a = 0; a < ret.length; a++) {
            ret[a] = new StockSlot(ResourceType.getResourceTypes()[a], 0);
        }

        for (int j = 0; j < this.size; j++) {
            for (int i = 0; i < this.size; i++) {
                if (this.grid[i][j].getOutputStock() != null) {
                    int typeid = this.grid[i][j].getOutputStock().getType().getResID();

                    ret[typeid].addAmount(this.grid[i][j].getOutputStock().getAmount());
                }
            }
        }
        for (int b = 0; b < ret.length; b++) {
            System.out.println(ret[b].getType() + "  :  " + ret[b].getAmount());
        }


        return ret;
    }

    public Cell getNearestCellByType(Cell cell, CellType type) {

        Cell ret;
        int X = cell.getX();
        int Y = cell.getY();


        for (int a = 1; a < this.size; a++) {
            for (int j = -a; j <= a; j++) {
                for (int i = -a; i <= a; i++) {
                    ret = this.getCell(X + i, Y + j);
                    if (ret != null) {
                        if (ret.getCellType() == type) {
                            return ret;
                        }
                    }
                }
            }
        }

        return null;
    }

    public void printBuildingsStatus() {
        for (int j = 0; j < this.size; j++) {
            for (int i = 0; i < this.size; i++) {
                Cell cell = this.grid[i][j];
                if (cell.getCellType().isUpgradable()) {
                    System.out.println(cell.getCellType() + " Lv.: " + cell.getLevel() + " " + cell.getCellClass() + " " + cell.getCellState());
                }
            }
        }
    }

    public int getCountOfCellType(CellType type) {
        int count = 0;
        for (int i = 0; i < this.grid.length; i++) {
            for (int j = 0; j < this.grid[0].length; j++) {
                if (this.grid[i][j].getCellType() == type) {
                    count++;
                }
            }
        }
        return count;
    }

    public void toImg() {
        int cl = 5;
        BufferedImage bimg = new BufferedImage(this.size * cl, this.size * cl, 1 /*
                 * TYPE_INT_RGB
                 */);
        Graphics gr = bimg.getGraphics();

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                CellType type = this.getCell(i, j).getCellType();

                switch (type) {
                    case RIVER:
                        gr.setColor(new Color(0, 130, 180));
                        gr.fillRect(i * cl, j * cl, cl, cl);
                        break;
                    case PLAINS:
                        gr.setColor(new Color(0, 160, 20));
                        gr.fillRect(i * cl, j * cl, cl, cl);
                        break;
                    case FOREST:
                        gr.setColor(new Color(0, 120, 40));
                        gr.fillRect(i * cl, j * cl, cl, cl);
                        break;
                    case POND:
                        gr.setColor(new Color(0, 160, 20));
                        gr.fillRect(i * cl, j * cl, cl, cl);
                        gr.setColor(new Color(0, 170, 160));
                        gr.fillOval(i * cl, j * cl, cl-1, cl-1);
                        break;
                    case QUARRY:
                        gr.setColor(new Color(170, 170, 160));
                        gr.fillRect(i * cl, j * cl, cl, cl);
                        break;
                    case SWAMP:
                        gr.setColor(Color.BLACK);
                        gr.fillRect(i * cl, j * cl, cl, cl);
                        break;
                    case ORE_MOUNT:
                        gr.setColor(new Color(70, 50, 30));
                        gr.fillRect(i * cl, j * cl, cl, cl);
                        break;
                    case FIELD:
                        gr.setColor(new Color(170, 170, 20));
                        gr.fillRect(i * cl, j * cl, cl, cl);
                        break;
                    case CASTLE:
                        gr.setColor(new Color(200, 10, 200));
                        gr.fillRect(i * cl, j * cl, cl, cl);
                        break;
                    default:
                        gr.setColor(Color.red);
                        gr.fillRect(i * cl, j * cl, cl, cl);
                        break;
                }


                
            }
        }
        try {
            ImageIO.write(bimg, "png", new File("imgs" + File.separator + "map_size_" + size + "_seed_" + this.seed + ".png"));
        } catch (IOException ex) {
            System.err.println("Nepovedlo se uložit obrazek mapy.");
        }

    }
}
