/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.libtowns.data.parts;

import java.io.Serializable;

/**
 *
 * @author rkriebel
 */
public class MarketTrigger implements Serializable {

    public final ResourceType type;
    private boolean buyactive = false;
    private boolean sellactive = false;
    private int lessthenbuy;
    private int morethensell;

    public MarketTrigger(ResourceType type, int minthebuy, int maxthensell) {
        this.type = type;
        this.lessthenbuy = minthebuy;
        this.morethensell = maxthensell;
    }

    public boolean isBuyactive() {
        return buyactive;
    }

    public void setBuyactive(boolean buyactive) {
        this.buyactive = buyactive;
    }

    public boolean isSellactive() {
        return sellactive;
    }

    public void setSellactive(boolean sellactive) {
        this.sellactive = sellactive;
    }

    public int getLessthenbuy() {
        return lessthenbuy;
    }

    public void setLessthenbuy(int lessthenbuy) {
        this.lessthenbuy = lessthenbuy;
        
        if(this.morethensell <= this.lessthenbuy){
            this.morethensell =  this.lessthenbuy  + 1;
        }
    }

    public int getMorethensell() {
        return morethensell;
    }

    public void setMorethensell(int morethensell) {
        this.morethensell = morethensell;
        
        if(this.morethensell <= this.lessthenbuy){
            this.lessthenbuy = this.morethensell -1;
        }
    }

    

    
}
