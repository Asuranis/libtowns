package com.libtowns.data.parts;

import java.io.Serializable;
import java.util.Random;

/**
 *
 * @author rkriebel
 */
public class Cell implements Serializable {

    private final byte X;
    private final byte Y;
    private byte typeID;
    private byte subtypeID;
    private byte nmb;
    private boolean isActive = true;
    private byte level = 1;
    private int timer = 25;
    private int unkeeptimer = 7;
    private StockSlot[] inputstock = null;
    private StockSlot[] unkeepstock = null;
    private StockSlot outputstock = null;
    private CellClass cellclass = CellClass.BUILDING_LOT;
    private CellState cellstate = CellState.NAPPING;
    private boolean townieWorking = false;

    public Cell(int X, int Y, CellType type) {
        this.level = 1;
        this.X = (byte) X;
        this.Y = (byte) Y;
        this.typeID = (byte) type.getCellID();
        this.subtypeID = (byte) new Random().nextInt(3);
        this.nmb = (byte) new Random().nextInt(Byte.MAX_VALUE);
    }

    public Cell(int i, int j) {
        this.level = 1;
        this.X = (byte) i;
        this.Y = (byte) j;
        this.typeID = 1;
        this.subtypeID = (byte) new Random().nextInt(3);
        this.nmb = (byte) new Random().nextInt(Byte.MAX_VALUE);
    }

    public int getSubTypeID() {
        return subtypeID;
    }

    public byte getTypeID() {
        return typeID;
    }

    public void setSubtypeID(int subtypeID) {
        this.subtypeID = (byte) subtypeID;
    }

    public CellType getCellType() {
        return CellType.getByID(this.typeID);
    }

    public CellClass getCellClass() {
        return cellclass;
    }

    public void setCellClass(CellClass bclass) {
        this.cellclass = bclass;
    }

    public boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(boolean isActive) {
        this.isActive = isActive;
    }

    public CellState getCellState() {
        return cellstate;
    }

    public void setState(CellState bstate) {
        this.cellstate = bstate;
    }

    public long getTimer() {
        return timer;
    }

    public void setTimer(int timer) {
        this.timer = timer;
    }

    public void decreaseTimer() {
        this.timer--;
    }

    public int capacity() {
        if (this.cellclass != CellClass.NATURE) {
            switch (level) {
                default:
                    return 16;
                case 1:
                    return 16;
                case 2:
                    return 32;
                case 3:
                    return 64;
            }
        } else {
            return -1;
        }
    }

    public byte getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = (byte) level;
    }

    public StockSlot getOutputStock() {
        return outputstock;
    }

    public void setOutputStock(StockSlot outputstock) {
        this.outputstock = outputstock;
    }

    public boolean equals(Cell cell) {
        return this.X == cell.X
                && this.Y == cell.Y
                && this.typeID == cell.typeID
                && this.subtypeID == cell.subtypeID
                && this.nmb == cell.nmb;
    }

    public StockSlot[] getInputStock() {
        return inputstock;
    }

    public void setInputStock(StockSlot[] inputstock) {
        this.inputstock = inputstock;
    }

    public StockSlot[] getUnkeepStock() {
        return unkeepstock;
    }

    public void setUnkeepStock(StockSlot[] unkeepstock) {
        this.unkeepstock = unkeepstock;
    }

    public boolean isOn(byte x, byte y) {
        return this.getX() == x && this.getY() == y;
    }

    public byte getX() {
        return X;
    }

    public byte getY() {
        return Y;
    }

    public boolean isTownieWorking() {
        return townieWorking;
    }

    public void setTownieWorking(boolean townieWorking) {
        this.townieWorking = townieWorking;
    }

    public void recreate() {
        recreate(CellType.PLAINS);
    }

    public void recreate(CellType type) {
        recreate(type, new Random().nextInt(3));
    }

    public void recreate(CellType type, int subType) {
        this.typeID = (byte) type.getCellID();
        this.subtypeID = (byte) subType;
        this.cellclass = CellClass.BUILDING_LOT;
        this.cellstate = CellState.NAPPING;

        isActive = true;
        level = 1;
        timer = new Random().nextInt(25) + 10;
        this.unkeeptimer = 7;
        inputstock = null;
        unkeepstock = null;
        this.outputstock = CellConstants.getOutputResourcesStock(this.getCellType(), this.level);
        this.townieWorking = false;
    }

    public void decreaseUnkeepTimer() {
        this.unkeeptimer--;
    }

    public void ressetUnkeepTimer() {
        this.unkeeptimer = 7;
    }

    public int getUnkeepTimer() {
        return this.unkeeptimer;
    }

    public void creationComplete() {
        this.setCellClass(CellClass.getDefaultCellClass(this.getCellType()));
        this.setState(CellState.WAITING_TO_EMPTY);

        //
        this.timer = 0;
        this.unkeeptimer = 7;

        //
        this.inputstock = null;
        this.unkeepstock = null;
        this.outputstock = CellConstants.getOutputResourcesStock(CellType.getByID(this.typeID), this.getLevel());

        if (this.getCellClass() == CellClass.SOURCE) {
            this.outputstock.setAmount(this.outputstock.getType().getInitialCapacity());
        } else if (this.getCellClass() == CellClass.GATHER_BUILDING || this.getCellClass() == CellClass.FACTORY_BUILDING) {
            this.outputstock.setAmount(0);
            this.inputstock = CellConstants.getInputResourcesStock(this.getCellType(), this.getLevel());
            this.unkeepstock = CellConstants.getUnkeepStock(this.getCellType(), this.getLevel());
        }
    }

    public void freeBuild() {
        this.timer = CellConstants.getBuildingLotTimeout(this.getCellType(), this.getLevel());
        this.cellclass = CellClass.BUILDING_LOT;
        this.cellstate = CellState.UNDER_CONSTRUCTION;
    }

    public int getAmountInOutputStock() {
        return this.outputstock.getAmount();
    }

    public boolean canAcceptResource(ResourceType type) {
        if (this.unkeepstock != null) {
            for (int i = 0; i < this.unkeepstock.length; i++) {
                if (this.unkeepstock[i].getType() == type) {
                    return true;
                }
            }
        }

        if (this.inputstock != null) {
            for (int i = 0; i < this.inputstock.length; i++) {
                if (this.inputstock[i].getType() == type) {
                    return true;
                }
            }
        }
        return false;
    }

    public void upgrade() {
        if (this.cellclass != CellClass.BUILDING_LOT && this.getCellType().isUpgradable() && this.level < 3) {
            isActive = true;
            this.level =  (byte) (this.level + 1);
            this.cellclass = CellClass.BUILDING_LOT;
            this.cellstate = CellState.NAPPING;
            this.inputstock = CellConstants.getBuildingLotStock(this.getCellType(), this.level );            
        }
    }
}
