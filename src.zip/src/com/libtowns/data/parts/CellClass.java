package com.libtowns.data.parts;

/**
 *
 * @author rkriebel
 */
public enum CellClass {

    PUBLIC_BUILDING,
    GATHER_BUILDING,
    FACTORY_BUILDING,
    BUILDING_LOT,
    NATURE,
    SOURCE;

    public static CellClass getDefaultCellClass(CellType ttype) {

        switch (ttype) {
            case RIVER:
                return NATURE;
            case PLAINS:
                return NATURE;
            case SWAMP:
                return NATURE;
            case FOREST:
                return SOURCE;
            case POND:
                return SOURCE;
            case QUARRY:
                return SOURCE;
            case ORE_MOUNT:
                return SOURCE;
            case FIELD:
                return SOURCE;
            case CASTLE:
                return PUBLIC_BUILDING;
            case MARKET:
                return PUBLIC_BUILDING;
            case WOODCUTTER:
                return GATHER_BUILDING;
            case STONECUTTER:
                return GATHER_BUILDING;
            case FISHERMAN:
                return GATHER_BUILDING;
            case SAWMILL:
                return FACTORY_BUILDING;
            case FARM:
                return GATHER_BUILDING;
            case PIG_FARM:
                return FACTORY_BUILDING;
            case BUTCHER:
                return FACTORY_BUILDING;
            case MILL:
                return FACTORY_BUILDING;
            case BAKERY:
                return FACTORY_BUILDING;
            case ORE_MINER:
                return GATHER_BUILDING;
            case FOUNDRY:
                return FACTORY_BUILDING;
            case SMITHY:
                return FACTORY_BUILDING;
        }

        return NATURE;
    }
}
