package com.libtowns.data.parts;

/**
 *
 * @author rkriebel
 */
public enum TownieState {

    ASSIGNED,
    //
    WAITING_FOR_RESOURCES, // CARRIER only
    //
    MOVING_TO_TARGET,
    //
    GATHER, // WORKER only
    //
    MOVING_TO_ORIGIN,
    //
    UNASSIGNED;
}
