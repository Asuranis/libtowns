package com.libtowns.data.parts;

import com.libtowns.GlobalConstants;

/**
 *
 * @author rkriebel
 */
public class CellConstants {

    public static StockSlot[] getBuildPrice(CellType type, int level) {
        StockSlot[] ret = instance().buildPrices[type.getCellID()][level - 1];
        return ret;
    }

    public static StockSlot[] getBuildingLotStock(CellType type, int level) {
        StockSlot[] ret = instance().AgetBuildPrice(type, level);
        if (ret != null) {
            for (int i = 0; i < ret.length; i++) {
                ret[i].setAmount(0);
            }
        }
        return ret;
    }

    public static StockSlot[] getUnkeepPrice(CellType type, int level) {
        StockSlot[] ret = instance().unkeepPrices[type.getCellID()][level - 1];
        return ret;
    }

    public static StockSlot[] getUnkeepStock(CellType type, int level) {
        StockSlot[] ret = instance().AgetUnkeepPrice(type, level);
        if (ret != null) {
            for (int i = 0; i < ret.length; i++) {
                ret[i].setAmount(0);
            }
        }
        return ret;
    }

    public static StockSlot[] getInputPrice(CellType type, int level) {
        int pom = 0;
        for (int i = 0; i < CellType.allTypes().length; i++) {
            if (CellType.allTypes()[i] == type) {
                pom = i;
                break;
            }
        }
        return instance().productionPrices[pom][level - 1];
    }

    public static StockSlot[] getInputResourcesStock(CellType type, int level) {
        StockSlot[] ret = instance().AgetInputResourcesPrices(type, level);

        if (ret != null) {
            for (int i = 0; i < ret.length; i++) {
                ret[i].setAmount(0);
            }
        }

        return ret;
    }

    public static StockSlot getOutputResource(CellType type, int level) {

        return instance().outputAmount[type.getCellID()][level - 1];
    }

    public static StockSlot getOutputResourcesStock(CellType type, int level) {

        StockSlot ret = instance().AgetOutputResourceAmount(type, level);

        if (ret != null) {
            ret.setAmount(0);
        }
        return ret;
    }

    public static int getBuildingLotTimeout(CellType tileType, int level) {

        switch (tileType) {
            case PLAINS:
                return (int) (GlobalConstants.ticks_per_day * 5f);
            case FOREST:
                return (int) (GlobalConstants.ticks_per_day * 7f);
            case POND:
                return (int) (GlobalConstants.ticks_per_day * 7f);
            case FIELD:
                return (int) (GlobalConstants.ticks_per_day * 6f);
            case CASTLE:
                return (int) (GlobalConstants.ticks_per_day * 7f * level);
            case MARKET:
                return (int) (GlobalConstants.ticks_per_day * 5f * level);
            case WOODCUTTER:
                return (int) (GlobalConstants.ticks_per_day * 1.25f * level);
            case FISHERMAN:
                return (int) (GlobalConstants.ticks_per_day * 1.5f * level);
            case STONECUTTER:
                return (int) (GlobalConstants.ticks_per_day * 2.2f * level);
            case SAWMILL:
                return (int) (GlobalConstants.ticks_per_day * 3.5f * level);
            case FARM:
                return (int) (GlobalConstants.ticks_per_day * 6.5f * level);
            case PIG_FARM:
                return (int) (GlobalConstants.ticks_per_day * 5f * level);
            case MILL:
                return (int) (GlobalConstants.ticks_per_day * 4f * level);
            case BAKERY:
                return (int) (GlobalConstants.ticks_per_day * 4f * level);
            case ORE_MINER:
                return (int) (GlobalConstants.ticks_per_day * 2.5f * level);
            case FOUNDRY:
                return (int) (GlobalConstants.ticks_per_day * 5f * level);
            case SMITHY:
                return (int) (GlobalConstants.ticks_per_day * 6f * level);


        }
        return (int) (GlobalConstants.ticks_per_day * 5);
    }

    public static int getProducingTime(CellType type) {
        switch (type) {
            case WOODCUTTER:
                return (int) (GlobalConstants.ticks_per_day * 0.25f);
            case STONECUTTER:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case FISHERMAN:
                return (int) (GlobalConstants.ticks_per_day * 0.25f);
            case SAWMILL:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case FARM:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case PIG_FARM:
                return (int) (GlobalConstants.ticks_per_day * 1f);
            case BUTCHER:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case MILL:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case BAKERY:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case ORE_MINER:
                return (int) (GlobalConstants.ticks_per_day * 0.75f);
            case FOUNDRY:
                return (int) (GlobalConstants.ticks_per_day * 0.75f);
            case SMITHY:
                return (int) (GlobalConstants.ticks_per_day * 1f);
        }
        return (int) (GlobalConstants.ticks_per_day);
    }

    public static int getNapTime(CellType type) {
        switch (type) {
            case WOODCUTTER:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case STONECUTTER:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case FISHERMAN:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case SAWMILL:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case FARM:
                return (int) (GlobalConstants.ticks_per_day * 2f);
            case PIG_FARM:
                return (int) (GlobalConstants.ticks_per_day * 1f);
            case BUTCHER:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case MILL:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case BAKERY:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case ORE_MINER:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case FOUNDRY:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
            case SMITHY:
                return (int) (GlobalConstants.ticks_per_day * 0.5f);
        }
        return (int) (GlobalConstants.ticks_per_day);
    }
    //Singleton constants DB////////////////////////////////////////////////////
    private static CellConstants instance;
    private final StockSlot[][][] buildPrices;
    private final StockSlot[][][] productionPrices;
    private final StockSlot[][][] unkeepPrices;
    private final StockSlot[][] outputAmount;

    private static CellConstants instance() {
        if (CellConstants.instance == null) {
            CellConstants.instance = new CellConstants();
        }
        return CellConstants.instance;
    }

    private CellConstants() {
        System.out.println("INITIALIZE CELL CONSTANTS DB");
        long timestamp = System.currentTimeMillis();
        CellType[] types = CellType.allTypes();

        this.buildPrices = new StockSlot[types.length][3][];
        for (int i = 0; i < this.buildPrices.length; i++) {
            for (int j = 0; j < this.buildPrices[0].length; j++) {
                this.buildPrices[i][j] = AgetBuildPrice(types[i], j + 1);
            }
        }

        this.productionPrices = new StockSlot[types.length][3][];
        for (int i = 0; i < this.productionPrices.length; i++) {
            for (int j = 0; j < this.productionPrices[0].length; j++) {
                this.productionPrices[i][j] = AgetInputResourcesPrices(types[i], j + 1);
            }
        }

        this.unkeepPrices = new StockSlot[types.length][3][];
        for (int i = 0; i < this.unkeepPrices.length; i++) {
            for (int j = 0; j < this.unkeepPrices[0].length; j++) {
                this.unkeepPrices[i][j] = AgetUnkeepPrice(types[i], j + 1);
            }
        }

        this.outputAmount = new StockSlot[types.length][3];
        for (int i = 0; i < this.outputAmount.length; i++) {
            for (int j = 0; j < this.outputAmount[0].length; j++) {
                this.outputAmount[i][j] = AgetOutputResourceAmount(types[i], j + 1);
            }
        }

        System.out.println("INITIALIZE CONSTANTS DB COMPLETED " + (System.currentTimeMillis() - timestamp) + " ms");
    }

    private StockSlot[] AgetBuildPrice(CellType type, int level) {
        StockSlot[] ret = null;
        switch (level) {
            case 1:
                switch (type) {
                    case PLAINS:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.COINS, 50);
                        break;
                    case FOREST:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.COINS, 75);
                        break;
                    case POND:
                        ret = new StockSlot[2];
                        ret[0] = new StockSlot(ResourceType.COINS, 75);
                        ret[1] = new StockSlot(ResourceType.TOOLS, 1);
                        break;
                    case FIELD:
                        ret = new StockSlot[2];
                        ret[0] = new StockSlot(ResourceType.COINS, 50);
                        ret[1] = new StockSlot(ResourceType.WHEAT, 2);
                        break;
                    case MARKET:
                        ret = new StockSlot[4];
                        ret[0] = new StockSlot(ResourceType.COINS, 100);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 20);
                        ret[2] = new StockSlot(ResourceType.STONES, 10);
                        ret[3] = new StockSlot(ResourceType.ANY_FOOD, 10);
                        break;
                    case WOODCUTTER:
                        ret = new StockSlot[2];
                        ret[0] = new StockSlot(ResourceType.COINS, 15);
                        ret[1] = new StockSlot(ResourceType.LOGS, 5);
                        break;
                    case STONECUTTER:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.COINS, 20);
                        ret[1] = new StockSlot(ResourceType.LOGS, 5);
                        ret[2] = new StockSlot(ResourceType.ANY_FOOD, 2);
                        break;
                    case FISHERMAN:
                        ret = new StockSlot[2];
                        ret[0] = new StockSlot(ResourceType.COINS, 15);
                        ret[1] = new StockSlot(ResourceType.LOGS, 5);
                        break;
                    case SAWMILL:
                        ret = new StockSlot[4];
                        ret[0] = new StockSlot(ResourceType.COINS, 30);
                        ret[1] = new StockSlot(ResourceType.LOGS, 10);
                        ret[2] = new StockSlot(ResourceType.STONES, 5);
                        ret[3] = new StockSlot(ResourceType.ANY_FOOD, 5);
                        break;
                    case FARM:
                        ret = new StockSlot[4];
                        ret[0] = new StockSlot(ResourceType.COINS, 50);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 10);
                        ret[2] = new StockSlot(ResourceType.STONES, 5);
                        ret[3] = new StockSlot(ResourceType.WHEAT, 2);
                        break;
                    case PIG_FARM:
                        ret = new StockSlot[4];
                        ret[0] = new StockSlot(ResourceType.COINS, 75);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 10);
                        ret[2] = new StockSlot(ResourceType.STONES, 5);
                        ret[3] = new StockSlot(ResourceType.WHEAT, 2);
                        break;
                    case BUTCHER:
                        ret = new StockSlot[4];
                        ret[0] = new StockSlot(ResourceType.COINS, 100);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 10);
                        ret[2] = new StockSlot(ResourceType.STONES, 10);
                        ret[3] = new StockSlot(ResourceType.ANY_FOOD, 2);
                        break;
                    case MILL:
                        ret = new StockSlot[4];
                        ret[0] = new StockSlot(ResourceType.COINS, 100);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 20);
                        ret[2] = new StockSlot(ResourceType.STONES, 15);
                        ret[3] = new StockSlot(ResourceType.ANY_FOOD, 2);
                        break;
                    case BAKERY:
                        ret = new StockSlot[4];
                        ret[0] = new StockSlot(ResourceType.COINS, 100);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 20);
                        ret[2] = new StockSlot(ResourceType.STONES, 10);
                        ret[3] = new StockSlot(ResourceType.ANY_FOOD, 2);
                        break;
                    case ORE_MINER:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.COINS, 50);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 10);
                        ret[2] = new StockSlot(ResourceType.ANY_FOOD, 5);
                        break;
                    case FOUNDRY:
                        ret = new StockSlot[4];
                        ret[0] = new StockSlot(ResourceType.COINS, 75);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 20);
                        ret[2] = new StockSlot(ResourceType.STONES, 20);
                        ret[3] = new StockSlot(ResourceType.ANY_FOOD, 10);
                        break;
                    case SMITHY:
                        ret = new StockSlot[5];
                        ret[0] = new StockSlot(ResourceType.COINS, 100);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 20);
                        ret[2] = new StockSlot(ResourceType.STONES, 20);
                        ret[3] = new StockSlot(ResourceType.IRON, 2);
                        ret[4] = new StockSlot(ResourceType.ANY_FOOD, 10);
                        break;
                }
                break;
            case 2:
                switch (type) {
                    case CASTLE:
                        ret = new StockSlot[6];
                        ret[0] = new StockSlot(ResourceType.COINS, 300);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 40);
                        ret[2] = new StockSlot(ResourceType.STONES, 50);
                        ret[3] = new StockSlot(ResourceType.IRON, 15);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 15);
                        ret[5] = new StockSlot(ResourceType.ANY_FOOD, 20);
                        break;
                    case MARKET:
                        ret = new StockSlot[5];
                        ret[0] = new StockSlot(ResourceType.COINS, 250);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 30);
                        ret[2] = new StockSlot(ResourceType.STONES, 20);
                        ret[3] = new StockSlot(ResourceType.TOOLS, 10);
                        ret[4] = new StockSlot(ResourceType.ANY_FOOD, 20);
                        break;
                    case WOODCUTTER:
                        ret = new StockSlot[5];
                        ret[0] = new StockSlot(ResourceType.COINS, 50);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 20);
                        ret[2] = new StockSlot(ResourceType.IRON, 5);
                        ret[3] = new StockSlot(ResourceType.TOOLS, 5);
                        ret[4] = new StockSlot(ResourceType.ANY_FOOD, 10);
                        break;
                    case STONECUTTER:
                        ret = new StockSlot[5];
                        ret[0] = new StockSlot(ResourceType.COINS, 60);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 20);
                        ret[2] = new StockSlot(ResourceType.IRON, 5);
                        ret[3] = new StockSlot(ResourceType.TOOLS, 5);
                        ret[4] = new StockSlot(ResourceType.ANY_FOOD, 15);
                        break;
                    case FISHERMAN:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.COINS, 40);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 20);
                        ret[2] = new StockSlot(ResourceType.TOOLS, 5);
                        break;
                    case SAWMILL:
                        ret = new StockSlot[6];
                        ret[0] = new StockSlot(ResourceType.COINS, 80);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 20);
                        ret[2] = new StockSlot(ResourceType.STONES, 20);
                        ret[3] = new StockSlot(ResourceType.IRON, 5);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 5);
                        ret[5] = new StockSlot(ResourceType.ANY_FOOD, 15);
                        break;
                    case FARM:
                        ret = new StockSlot[5];
                        ret[0] = new StockSlot(ResourceType.COINS, 120);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 30);
                        ret[2] = new StockSlot(ResourceType.STONES, 15);
                        ret[3] = new StockSlot(ResourceType.IRON, 10);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 10);
                        break;
                    case PIG_FARM:
                        ret = new StockSlot[5];
                        ret[0] = new StockSlot(ResourceType.COINS, 100);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 40);
                        ret[2] = new StockSlot(ResourceType.STONES, 10);
                        ret[3] = new StockSlot(ResourceType.WHEAT, 10);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 10);
                        break;
                    case BUTCHER:
                        ret = new StockSlot[6];
                        ret[0] = new StockSlot(ResourceType.COINS, 150);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 30);
                        ret[2] = new StockSlot(ResourceType.STONES, 20);
                        ret[3] = new StockSlot(ResourceType.IRON, 5);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 10);
                        ret[5] = new StockSlot(ResourceType.ANY_FOOD, 10);
                        break;
                    case MILL:
                        ret = new StockSlot[6];
                        ret[0] = new StockSlot(ResourceType.COINS, 100);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 40);
                        ret[2] = new StockSlot(ResourceType.STONES, 20);
                        ret[3] = new StockSlot(ResourceType.IRON, 10);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 10);
                        ret[5] = new StockSlot(ResourceType.ANY_FOOD, 10);
                        break;
                    case BAKERY:
                        ret = new StockSlot[6];
                        ret[0] = new StockSlot(ResourceType.COINS, 180);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 30);
                        ret[2] = new StockSlot(ResourceType.STONES, 20);
                        ret[3] = new StockSlot(ResourceType.IRON, 10);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 10);
                        ret[5] = new StockSlot(ResourceType.ANY_FOOD, 10);
                        break;
                    case ORE_MINER:
                        ret = new StockSlot[5];
                        ret[0] = new StockSlot(ResourceType.COINS, 100);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 20);
                        ret[2] = new StockSlot(ResourceType.STONES, 20);
                        ret[3] = new StockSlot(ResourceType.TOOLS, 10);
                        ret[4] = new StockSlot(ResourceType.ANY_FOOD, 15);
                        break;
                    case FOUNDRY:
                        ret = new StockSlot[5];
                        ret[0] = new StockSlot(ResourceType.COINS, 180);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 30);
                        ret[2] = new StockSlot(ResourceType.STONES, 50);
                        ret[3] = new StockSlot(ResourceType.TOOLS, 10);
                        ret[4] = new StockSlot(ResourceType.ANY_FOOD, 20);
                        break;
                    case SMITHY:
                        ret = new StockSlot[5];
                        ret[0] = new StockSlot(ResourceType.COINS, 200);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 40);
                        ret[2] = new StockSlot(ResourceType.STONES, 35);
                        ret[3] = new StockSlot(ResourceType.IRON, 20);
                        ret[4] = new StockSlot(ResourceType.ANY_FOOD, 20);
                        break;
                }
                break;
            case 3:
                switch (type) {
                    case CASTLE:
                        ret = new StockSlot[6];
                        ret[0] = new StockSlot(ResourceType.COINS, 800);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 80);
                        ret[2] = new StockSlot(ResourceType.STONES, 100);
                        ret[3] = new StockSlot(ResourceType.IRON, 40);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 40);
                        ret[5] = new StockSlot(ResourceType.ANY_FOOD, 50);
                        break;
                    case MARKET:
                        ret = new StockSlot[6];
                        ret[0] = new StockSlot(ResourceType.COINS, 600);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 110);
                        ret[2] = new StockSlot(ResourceType.STONES, 60);
                        ret[3] = new StockSlot(ResourceType.IRON, 20);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 30);
                        ret[5] = new StockSlot(ResourceType.ANY_FOOD, 40);
                        break;
                    case WOODCUTTER:
                        ret = new StockSlot[5];
                        ret[0] = new StockSlot(ResourceType.COINS, 200);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 50);
                        ret[2] = new StockSlot(ResourceType.IRON, 20);
                        ret[3] = new StockSlot(ResourceType.TOOLS, 15);
                        ret[4] = new StockSlot(ResourceType.ANY_FOOD, 20);
                        break;
                    case STONECUTTER:
                        ret = new StockSlot[5];
                        ret[0] = new StockSlot(ResourceType.COINS, 220);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 40);
                        ret[2] = new StockSlot(ResourceType.IRON, 15);
                        ret[3] = new StockSlot(ResourceType.TOOLS, 15);
                        ret[4] = new StockSlot(ResourceType.ANY_FOOD, 15);
                        break;
                    case FISHERMAN:
                        ret = new StockSlot[4];
                        ret[0] = new StockSlot(ResourceType.COINS, 180);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 60);
                        ret[2] = new StockSlot(ResourceType.STONES, 20);
                        ret[3] = new StockSlot(ResourceType.TOOLS, 10);
                        break;
                    case SAWMILL:
                        ret = new StockSlot[6];
                        ret[0] = new StockSlot(ResourceType.COINS, 380);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 80);
                        ret[2] = new StockSlot(ResourceType.STONES, 50);
                        ret[3] = new StockSlot(ResourceType.IRON, 35);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 25);
                        ret[5] = new StockSlot(ResourceType.ANY_FOOD, 15);
                        break;
                    case FARM:
                        ret = new StockSlot[6];
                        ret[0] = new StockSlot(ResourceType.COINS, 420);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 110);
                        ret[2] = new StockSlot(ResourceType.STONES, 35);
                        ret[3] = new StockSlot(ResourceType.IRON, 20);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 20);
                        ret[5] = new StockSlot(ResourceType.ANY_FOOD, 15);
                        break;
                    case PIG_FARM:
                        ret = new StockSlot[6];
                        ret[0] = new StockSlot(ResourceType.COINS, 350);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 60);
                        ret[2] = new StockSlot(ResourceType.STONES, 20);
                        ret[3] = new StockSlot(ResourceType.WHEAT, 30);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 20);
                        ret[5] = new StockSlot(ResourceType.ANY_FOOD, 15);
                        break;
                    case BUTCHER:
                        ret = new StockSlot[6];
                        ret[0] = new StockSlot(ResourceType.COINS, 400);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 60);
                        ret[2] = new StockSlot(ResourceType.STONES, 40);
                        ret[3] = new StockSlot(ResourceType.IRON, 20);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 25);
                        ret[5] = new StockSlot(ResourceType.ANY_FOOD, 20);
                        break;
                    case MILL:
                        ret = new StockSlot[6];
                        ret[0] = new StockSlot(ResourceType.COINS, 440);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 60);
                        ret[2] = new StockSlot(ResourceType.STONES, 60);
                        ret[3] = new StockSlot(ResourceType.IRON, 30);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 25);
                        ret[5] = new StockSlot(ResourceType.ANY_FOOD, 30);
                        break;
                    case BAKERY:
                        ret = new StockSlot[6];
                        ret[0] = new StockSlot(ResourceType.COINS, 400);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 55);
                        ret[2] = new StockSlot(ResourceType.STONES, 60);
                        ret[3] = new StockSlot(ResourceType.IRON, 25);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 20);
                        ret[5] = new StockSlot(ResourceType.ANY_FOOD, 25);
                        break;
                    case ORE_MINER:
                        ret = new StockSlot[5];
                        ret[0] = new StockSlot(ResourceType.COINS, 250);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 65);
                        ret[2] = new StockSlot(ResourceType.STONES, 30);
                        ret[3] = new StockSlot(ResourceType.TOOLS, 30);
                        ret[4] = new StockSlot(ResourceType.ANY_FOOD, 35);
                        break;
                    case FOUNDRY:
                        ret = new StockSlot[5];
                        ret[0] = new StockSlot(ResourceType.COINS, 380);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 65);
                        ret[2] = new StockSlot(ResourceType.STONES, 70);
                        ret[3] = new StockSlot(ResourceType.TOOLS, 30);
                        ret[4] = new StockSlot(ResourceType.ANY_FOOD, 40);
                        break;
                    case SMITHY:
                        ret = new StockSlot[6];
                        ret[0] = new StockSlot(ResourceType.COINS, 500);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 70);
                        ret[2] = new StockSlot(ResourceType.STONES, 60);
                        ret[3] = new StockSlot(ResourceType.IRON, 50);
                        ret[4] = new StockSlot(ResourceType.TOOLS, 30);
                        ret[5] = new StockSlot(ResourceType.ANY_FOOD, 40);
                        break;
                }
                break;

        }
        return ret;
    }

    private StockSlot[] AgetUnkeepPrice(CellType type, int level) {
        StockSlot[] ret = null;
        switch (level) {
            case 1:
                switch (type) {
                    case WOODCUTTER:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 7);
                        break;
                    case STONECUTTER:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 7);
                        break;
                    case SAWMILL:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 7);
                        break;
                    case FARM:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.LOGS, 1);
                        break;
                    case PIG_FARM:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.PLANKS, 1);
                        break;
                    case BUTCHER:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.LOGS, 7);
                        break;
                    case MILL:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.STONES, 1);
                        break;
                    case BAKERY:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.LOGS, 7);
                        break;
                    case ORE_MINER:
                        ret = new StockSlot[2];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 7);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 1);
                        break;
                    case FOUNDRY:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 7);
                        break;
                    case SMITHY:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 7);
                        break;
                }
                break;
            case 2:
                switch (type) {
                    case WOODCUTTER:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 12);
                        ret[1] = new StockSlot(ResourceType.COINS, 5);
                        ret[2] = new StockSlot(ResourceType.TOOLS, 1);
                        break;
                    case FISHERMAN:
                        ret = new StockSlot[2];
                        ret[0] = new StockSlot(ResourceType.PLANKS, 2);
                        ret[1] = new StockSlot(ResourceType.COINS, 5);
                        break;
                    case STONECUTTER:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 12);
                        ret[1] = new StockSlot(ResourceType.COINS, 5);
                        ret[2] = new StockSlot(ResourceType.TOOLS, 1);
                        break;
                    case SAWMILL:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 12);
                        ret[1] = new StockSlot(ResourceType.COINS, 10);
                        ret[2] = new StockSlot(ResourceType.TOOLS, 2);
                        break;
                    case FARM:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.PLANKS, 2);
                        ret[1] = new StockSlot(ResourceType.COINS, 3);
                        ret[2] = new StockSlot(ResourceType.TOOLS, 1);
                        break;
                    case PIG_FARM:
                        ret = new StockSlot[2];
                        ret[0] = new StockSlot(ResourceType.PLANKS, 3);
                        ret[1] = new StockSlot(ResourceType.TOOLS, 1);
                        break;
                    case BUTCHER:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.PLANKS, 3);
                        ret[1] = new StockSlot(ResourceType.TOOLS, 1);
                        ret[2] = new StockSlot(ResourceType.COINS, 10);
                        break;
                    case MILL:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.STONES, 3);
                        ret[1] = new StockSlot(ResourceType.TOOLS, 1);
                        ret[2] = new StockSlot(ResourceType.COINS, 10);
                        break;
                    case BAKERY:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.LOGS, 16);
                        ret[1] = new StockSlot(ResourceType.STONES, 1);
                        ret[2] = new StockSlot(ResourceType.COINS, 5);
                        break;
                    case ORE_MINER:
                        ret = new StockSlot[4];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 10);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 3);
                        ret[2] = new StockSlot(ResourceType.COINS, 5);
                        ret[3] = new StockSlot(ResourceType.TOOLS, 1);
                        break;
                    case FOUNDRY:
                        ret = new StockSlot[4];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 12);
                        ret[1] = new StockSlot(ResourceType.STONES, 3);
                        ret[2] = new StockSlot(ResourceType.COINS, 10);
                        ret[3] = new StockSlot(ResourceType.TOOLS, 1);
                        break;
                    case SMITHY:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 12);
                        ret[1] = new StockSlot(ResourceType.IRON, 2);
                        ret[2] = new StockSlot(ResourceType.COINS, 12);
                        break;
                }
                break;
            case 3:
                switch (type) {
                    case WOODCUTTER:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 18);
                        ret[1] = new StockSlot(ResourceType.COINS, 8);
                        ret[2] = new StockSlot(ResourceType.TOOLS, 1);
                        break;
                    case FISHERMAN:
                        ret = new StockSlot[2];
                        ret[0] = new StockSlot(ResourceType.PLANKS, 4);
                        ret[1] = new StockSlot(ResourceType.COINS, 6);
                        break;
                    case STONECUTTER:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 18);
                        ret[1] = new StockSlot(ResourceType.COINS, 8);
                        ret[2] = new StockSlot(ResourceType.TOOLS, 1);
                        break;
                    case SAWMILL:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 18);
                        ret[1] = new StockSlot(ResourceType.COINS, 16);
                        ret[2] = new StockSlot(ResourceType.TOOLS, 2);
                        break;
                    case FARM:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.PLANKS, 6);
                        ret[1] = new StockSlot(ResourceType.COINS, 6);
                        ret[2] = new StockSlot(ResourceType.TOOLS, 1);
                        break;
                    case PIG_FARM:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.PLANKS, 8);
                        ret[1] = new StockSlot(ResourceType.COINS, 6);
                        ret[2] = new StockSlot(ResourceType.TOOLS, 1);
                        break;
                    case BUTCHER:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.PLANKS, 6);
                        ret[1] = new StockSlot(ResourceType.TOOLS, 1);
                        ret[2] = new StockSlot(ResourceType.COINS, 16);
                        break;
                    case MILL:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.STONES, 5);
                        ret[1] = new StockSlot(ResourceType.TOOLS, 1);
                        ret[2] = new StockSlot(ResourceType.COINS, 16);
                        break;
                    case BAKERY:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.LOGS, 24);
                        ret[1] = new StockSlot(ResourceType.STONES, 1);
                        ret[2] = new StockSlot(ResourceType.COINS, 8);
                        break;
                    case ORE_MINER:
                        ret = new StockSlot[4];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 16);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 5);
                        ret[2] = new StockSlot(ResourceType.COINS, 10);
                        ret[3] = new StockSlot(ResourceType.TOOLS, 1);
                        break;
                    case FOUNDRY:
                        ret = new StockSlot[4];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 18);
                        ret[1] = new StockSlot(ResourceType.STONES, 5);
                        ret[2] = new StockSlot(ResourceType.COINS, 16);
                        ret[3] = new StockSlot(ResourceType.TOOLS, 1);
                        break;
                    case SMITHY:
                        ret = new StockSlot[3];
                        ret[0] = new StockSlot(ResourceType.ANY_FOOD, 18);
                        ret[1] = new StockSlot(ResourceType.IRON, 3);
                        ret[2] = new StockSlot(ResourceType.COINS, 18);
                        break;
                }
                break;
        }
        return ret;
    }

    private StockSlot[] AgetInputResourcesPrices(CellType type, int level) {
        StockSlot[] ret = null;
        switch (level) {
            case 1:
                switch (type) {
                    case SAWMILL:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.LOGS, 1);
                        break;
                    case PIG_FARM:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.WHEAT, 4);
                        break;
                    case BUTCHER:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.PIGS, 1);
                        break;
                    case MILL:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.WHEAT, 2);
                        break;
                    case BAKERY:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.FLOUR, 1);
                        break;
                    case FOUNDRY:
                        ret = new StockSlot[2];
                        ret[0] = new StockSlot(ResourceType.ORE, 2);
                        ret[1] = new StockSlot(ResourceType.LOGS, 3);
                        break;
                    case SMITHY:
                        ret = new StockSlot[2];
                        ret[0] = new StockSlot(ResourceType.IRON, 1);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 1);
                        break;
                }
                break;
            case 2:
                switch (type) {
                    case SAWMILL:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.LOGS, 2);
                        break;
                    case PIG_FARM:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.WHEAT, 6);
                        break;
                    case BUTCHER:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.PIGS, 2);
                        break;
                    case MILL:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.WHEAT, 3);
                        break;
                    case BAKERY:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.FLOUR, 2);
                        break;
                    case FOUNDRY:
                        ret = new StockSlot[2];
                        ret[0] = new StockSlot(ResourceType.ORE, 3);
                        ret[1] = new StockSlot(ResourceType.LOGS, 5);
                        break;
                    case SMITHY:
                        ret = new StockSlot[2];
                        ret[0] = new StockSlot(ResourceType.IRON, 2);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 1);
                        break;
                }
                break;
            case 3:
                switch (type) {
                    case SAWMILL:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.LOGS, 2);
                        break;
                    case PIG_FARM:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.WHEAT, 8);
                        break;
                    case BUTCHER:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.PIGS, 2);
                        break;
                    case MILL:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.WHEAT, 4);
                        break;
                    case BAKERY:
                        ret = new StockSlot[1];
                        ret[0] = new StockSlot(ResourceType.FLOUR, 3);
                        break;
                    case FOUNDRY:
                        ret = new StockSlot[2];
                        ret[0] = new StockSlot(ResourceType.ORE, 4);
                        ret[1] = new StockSlot(ResourceType.LOGS, 6);
                        break;
                    case SMITHY:
                        ret = new StockSlot[2];
                        ret[0] = new StockSlot(ResourceType.IRON, 2);
                        ret[1] = new StockSlot(ResourceType.PLANKS, 2);
                        break;
                }
                break;
        }
        return ret;
    }

    private StockSlot AgetOutputResourceAmount(CellType type, int level) {
        switch (level) {
            case 1:
                switch (type) {
                    case FOREST:
                        return new StockSlot(ResourceType.LOGS, ResourceType.LOGS.getInitialCapacity());
                    case POND:
                        return new StockSlot(ResourceType.FISH, ResourceType.FISH.getInitialCapacity());
                    case QUARRY:
                        return new StockSlot(ResourceType.STONES, ResourceType.STONES.getInitialCapacity());
                    case ORE_MOUNT:
                        return new StockSlot(ResourceType.ORE, ResourceType.ORE.getInitialCapacity());
                    case FIELD:
                        return new StockSlot(ResourceType.WHEAT, ResourceType.WHEAT.getInitialCapacity());
                    case WOODCUTTER:
                        return new StockSlot(ResourceType.LOGS, 2);
                    case STONECUTTER:
                        return new StockSlot(ResourceType.STONES, 2);
                    case FISHERMAN:
                        return new StockSlot(ResourceType.FISH, 2);
                    case SAWMILL:
                        return new StockSlot(ResourceType.PLANKS, 2);
                    case FARM:
                        return new StockSlot(ResourceType.WHEAT, 4);
                    case PIG_FARM:
                        return new StockSlot(ResourceType.PIGS, 2);
                    case BUTCHER:
                        return new StockSlot(ResourceType.PORK, 4);
                    case MILL:
                        return new StockSlot(ResourceType.FLOUR, 1);
                    case BAKERY:
                        return new StockSlot(ResourceType.BREADS, 2);
                    case ORE_MINER:
                        return new StockSlot(ResourceType.ORE, 2);
                    case FOUNDRY:
                        return new StockSlot(ResourceType.IRON, 1);
                    case SMITHY:
                        return new StockSlot(ResourceType.TOOLS, 2);
                }
                break;
            case 2:
                switch (type) {
                    case WOODCUTTER:
                        return new StockSlot(ResourceType.LOGS, 4);
                    case STONECUTTER:
                        return new StockSlot(ResourceType.STONES, 4);
                    case FISHERMAN:
                        return new StockSlot(ResourceType.FISH, 4);
                    case SAWMILL:
                        return new StockSlot(ResourceType.PLANKS, 4);
                    case FARM:
                        return new StockSlot(ResourceType.WHEAT, 8);
                    case PIG_FARM:
                        return new StockSlot(ResourceType.PIGS, 3);
                    case BUTCHER:
                        return new StockSlot(ResourceType.PORK, 8);
                    case MILL:
                        return new StockSlot(ResourceType.FLOUR, 2);
                    case BAKERY:
                        return new StockSlot(ResourceType.BREADS, 3);
                    case ORE_MINER:
                        return new StockSlot(ResourceType.ORE, 4);
                    case FOUNDRY:
                        return new StockSlot(ResourceType.IRON, 2);
                    case SMITHY:
                        return new StockSlot(ResourceType.TOOLS, 3);
                }
                break;
            case 3:
                switch (type) {
                    case WOODCUTTER:
                        return new StockSlot(ResourceType.LOGS, 6);
                    case STONECUTTER:
                        return new StockSlot(ResourceType.STONES, 6);
                    case FISHERMAN:
                        return new StockSlot(ResourceType.FISH, 6);
                    case SAWMILL:
                        return new StockSlot(ResourceType.PLANKS, 6);
                    case FARM:
                        return new StockSlot(ResourceType.WHEAT, 10);
                    case PIG_FARM:
                        return new StockSlot(ResourceType.PIGS, 4);
                    case BUTCHER:
                        return new StockSlot(ResourceType.PORK, 10);
                    case MILL:
                        return new StockSlot(ResourceType.FLOUR, 3);
                    case BAKERY:
                        return new StockSlot(ResourceType.BREADS, 5);
                    case ORE_MINER:
                        return new StockSlot(ResourceType.ORE, 6);
                    case FOUNDRY:
                        return new StockSlot(ResourceType.IRON, 3);
                    case SMITHY:
                        return new StockSlot(ResourceType.TOOLS, 5);
                }
                break;
        }
        return null;
    }
}
