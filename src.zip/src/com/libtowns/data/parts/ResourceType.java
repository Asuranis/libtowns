package com.libtowns.data.parts;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Created by robin on 26.10.15.
 */
public enum ResourceType {

    ANY_FOOD(-1, 0, 0f, 0, 0, false),
    //-----------------------------------------
    COINS(0, 1, 0f, 0, 0, false),
    LOGS(1, 1, 0.8f, 100, 200, false),
    PLANKS(2, 2, 0.5f, 0, 0, false),
    FISH(3, 1, 0.8f, 100, 500, true),
    STONES(4, 2, 1f, 500, 5000, false),
    WHEAT(5, 1, 0.4f,100, 250, false),
    ORE(6, 2, 0.6f, 500, 5000, false),
    IRON(7, 5, 0.3f, 0, 0, false),
    TOOLS(8, 10, 0.2f, 0, 0, false),
    FLOUR(9, 2, 0.25f, 0, 0, false),
    PIGS(10, 2, 0.6f, 0, 0, false),
    PORK(11, 2, 0.5f, 0, 0, true),
    BREADS(12, 3, 0.5f, 0, 0, true);
    private int resID;
    private int price;
    private float market_resource_change_coef;
    private int source_min_capacity;
    private int source_max_amount;
    private boolean isFood;

    private ResourceType(int resID, int price, float market_resource_change_coef, int source_min_capacity, int source_max_amount, boolean isFood) {
        this.resID = resID;
        this.price = price;
        this.market_resource_change_coef = market_resource_change_coef;
        this.source_min_capacity = source_min_capacity;
        this.source_max_amount = source_max_amount;
        this.isFood = isFood;
    }

    public static ResourceType getByID(int resID) {
        if (ResourceType.instance == null) {
            ResourceType.instance = ResourceType.ANY_FOOD;
            ResourceType.instance.init();
        }
        for (int i = 0; i < instance.types.length; i++) {
            if (instance.types[i].getResID() == resID) {
                return instance.types[i];
            }
        }
        return null;
    }

    public float getMarket_resource_change_coef() {
        return market_resource_change_coef;
    }

    public int getPrice() {
        return price;
    }

    public int getResID() {
        return resID;
    }

    public int getInitialCapacity() {
        int ret = this.source_min_capacity;
        if (this.source_max_amount > 1) {
            ret += new Random().nextInt(this.source_max_amount);
        }
        return ret;
    }

    public static ResourceType[] getResourceTypes() {
        if (ResourceType.instance == null) {
            ResourceType.instance = ResourceType.ANY_FOOD;
            ResourceType.instance.init();
        }
        return instance.types;
    }

    public boolean isFood() {
        return isFood;
    }

    public static ResourceType[] getFoodTypes() {
        if (ResourceType.instance == null) {
            ResourceType.instance = ResourceType.ANY_FOOD;
            ResourceType.instance.init();
        }
        return instance.foods;
    }
    private static ResourceType instance;
    private ResourceType[] types;
    private ResourceType[] foods;

    private void init() {
        this.types = this.values();

        List<ResourceType> tmp = new ArrayList();
        for (ResourceType type : this.types) {
            if (type.getResID() >= 0) {
                tmp.add(type);
            }
        }

        this.types = new ResourceType[tmp.size()];

        int counter = 0;
        for (int i = 0; i < types.length; i++) {
            types[i] = tmp.get(i);
            if (types[i].isFood()) {
                counter++;
            }
        }

        this.foods = new ResourceType[counter];
        counter = 0;

        for (int i = 0; i < types.length; i++) {
            if (types[i].isFood()) {
                this.foods[counter++] = types[i];
            }
        }


    }

    public int getMaxAmount() {
        return this.source_max_amount;
    }
}
