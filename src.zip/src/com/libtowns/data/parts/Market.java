package com.libtowns.data.parts;

/**
 *
 * @author rkriebel
 */
public class Market extends Stock {

    final MarketTrigger[] triggers;

    public Market() {
        triggers = new MarketTrigger[ResourceType.getResourceTypes().length];

        for (int i = 0; i < stock_slots.length; i++) {
            triggers[i] = new MarketTrigger(this.stock_slots[i].getType(), 5, 95);
        }

    }

    @Override
    public void printStockStatus() {
        for (int i = 0; i < stock_slots.length; i++) {
            System.out.println("item " + stock_slots[i].getType() + " onMarket: " + stock_slots[i].getAmount() + " / " + (int)(stock_slots[i].getType().getMarket_resource_change_coef()*this.getCapacity()) + " / " + this.getCapacity());
        }
    }

    public MarketTrigger[] getTriggers() {
        return this.triggers;
    }

    public MarketTrigger getTrigger(ResourceType type) {
        for (int i = 0; i < triggers.length; i++) {
            if (triggers[i].type == type) {
                return triggers[i];
            }
        }
        return null;
    }
}
