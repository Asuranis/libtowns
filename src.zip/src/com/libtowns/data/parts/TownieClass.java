package com.libtowns.data.parts;

/**
 *
 * @author rkriebel
 */
public enum TownieClass {
    NONE,
    WORKER,
    CARRIER;
}
