package com.libtowns.data.parts;

import java.io.Serializable;

/**
 *
 * @author rkriebel
 */
public class Stock implements Serializable {

    private int level = 1;
    final StockSlot[] stock_slots;

    public Stock() {
        stock_slots = new StockSlot[ResourceType.getResourceTypes().length];

        for (int i = 0; i < stock_slots.length; i++) {
            stock_slots[i] = new StockSlot(ResourceType.getByID(i), 0);
        }

        stock_slots[ResourceType.COINS.getResID()].setAmount(500);
        stock_slots[ResourceType.LOGS.getResID()].setAmount(30);
        stock_slots[ResourceType.FISH.getResID()].setAmount(30);
        stock_slots[ResourceType.WHEAT.getResID()].setAmount(10);
        stock_slots[ResourceType.TOOLS.getResID()].setAmount(5);
    }

    public void printStockStatus() {
        System.out.println("STOCK");
        for (int i = 0; i < stock_slots.length; i++) {
            System.out.println(stock_slots[i].getType() + " : " + stock_slots[i].getAmount() + " / " + this.getCapacity());
        }
    }

    public StockSlot[] getStockSlots() {
        return this.stock_slots;
    }

    public int getCapacity() {
        switch (level) {
            default:
                return 50;
            case 1:
                return 50;
            case 2:
                return 100;
            case 3:
                return 200;
        }
    }

    public void giveResource(ResourceType res, int amount) {
        if (amount > 0) {
            for (int i = 0; i < this.stock_slots.length; i++) {
                if (this.stock_slots[i].getType() == res) {
                    this.stock_slots[i].addAmount(amount);
                    if (res != ResourceType.COINS) {
                        if (this.stock_slots[i].getAmount() > this.getCapacity()) {
                            this.stock_slots[i].setAmount(this.getCapacity());
                        }
                    }
                }
            }
        }
    }

    public int getOutResource(ResourceType res, int amount) {
        int ret = -1;
        if (amount > 0) {
            for (int i = 0; i < this.stock_slots.length; i++) {
                if (this.stock_slots[i].getType() == res) {
                    this.stock_slots[i].decAmount(amount);

                    ret = this.stock_slots[i].getAmount();
                    if (ret < 0) {
                        ret = amount + ret;
                        this.stock_slots[i].setAmount(0);
                    } else {
                        ret = amount;
                    }
                    break;
                }
            }
        }
        return ret;
    }

    public boolean isFull(ResourceType res) {
        if (res != ResourceType.COINS) {
            for (int i = 1; i < this.stock_slots.length; i++) {
                if (this.stock_slots[i].getType() == res) {
                    return this.stock_slots[i].getAmount() >= this.getCapacity();
                }
            }
        }
        return false;
    }

    public int getAmount(ResourceType res) {
        for (int i = 0; i < this.stock_slots.length; i++) {
            if (this.stock_slots[i].getType() == res) {
                return this.stock_slots[i].getAmount();
            }
        }
        return 0;
    }

    public void setLevel(byte level) {
        this.level = level;
    }
    
    public int getLevel() {
        return this.level;
    }
}
