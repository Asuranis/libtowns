package com.libtowns.data.parts;

/**
 *
 * @author rkriebel
 */
public enum CellState {

    WAITING_FOR_RESOURCE,
    RECIEVED_RESOURCE,
    WAITING_TO_EMPTY,
    PRODUCING_TIME,
    NAPPING,
    WAITING_FOR_UNKEEP,
    RECIEVED_UNKEEP,
    //SPECIALS
    //Gathering
    WAITING_FOR_MISSING_SOURCE,
    //building lot
    UNDER_CONSTRUCTION;
}
