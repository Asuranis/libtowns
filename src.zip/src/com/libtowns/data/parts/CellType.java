package com.libtowns.data.parts;

/*
 * Created by robin on 26.10.15.
 */
public enum CellType {
    // ID, BUILDABLE, DESTROYABLE, UPGRADABLE

    RIVER(0, false, false, false),
    //--------------------------------------------------------------------------
    PLAINS(1, true, true, false),
    FOREST(2, true, true, false),
    //--------------------------------------------------------------------------
    POND(3, true, true, false),
    QUARRY(4, false, false, false),
    //--------------------------------------------------------------------------
    SWAMP(5, false, true, false),
    ORE_MOUNT(6, false, false, false),
    //--------------------------------------------------------------------------
    FIELD(7, true, true, false),
    //--------------------------------------------------------------------------
    // BUILDINGS
    CASTLE(8, false, false, true),
    //--------------------------------------------------------------------------
    MARKET(9, true, true, true),
    WOODCUTTER(10, true, true, true),
    //--------------------------------------------------------------------------
    STONECUTTER(11, true, true, true),
    FISHERMAN(12, true, true, true),
    //--------------------------------------------------------------------------
    SAWMILL(13, true, true, true),
    FARM(14, true, true, true),
    //--------------------------------------------------------------------------
    PIG_FARM(15, true, true, true),
    BUTCHER(16, true, true, true),
    //--------------------------------------------------------------------------
    MILL(17, true, true, true),
    BAKERY(18, true, true, true),
    //--------------------------------------------------------------------------
    ORE_MINER(19, true, true, true),
    FOUNDRY(20, true, true, true),
    //--------------------------------------------------------------------------
    SMITHY(21, true, true, true);
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    private final int cellID;
    private final boolean buildable;
    private final boolean destroyable;
    private final boolean upgradable;

    public static CellType getByID(int cellID) {
        if (CellType.instance == null) {
            CellType.instance = CellType.PLAINS;
            instance.init();
        }
        for (int i = 0; i < instance.types.length; i++) {
            if (instance.types[i].getCellID() == cellID) {
                return instance.types[i];
            }
        }
        return null;
    }

    private CellType(int cellID, boolean isBuildable, boolean isDestroyable, boolean upgradable) {
        this.cellID = cellID;
        this.buildable = isBuildable;
        this.destroyable = isDestroyable;
        this.upgradable = upgradable;
    }

    public boolean isBuildable() {
        return buildable;
    }

    public boolean isDestroyable() {
        return destroyable;
    }

    public int getCellID() {
        return cellID;
    }

    public boolean isUpgradable() {
        return upgradable;
    }

    public static CellType[] allTypes() {
        if (CellType.instance == null) {
            CellType.instance = CellType.PLAINS;
            instance.init();
        }
        return instance.types;
    }
    private static CellType instance;
    private CellType[] types;

    private void init() {
        this.types = new CellType[this.values().length];

        for (int i = 0; i < types.length; i++) {
            for (int j = 0; j < this.values().length; j++) {
                if (i == this.values()[j].getCellID()) {
                    types[i] = this.values()[j];
                }
            }
        }
    }
}
