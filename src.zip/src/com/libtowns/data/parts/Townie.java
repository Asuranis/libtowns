package com.libtowns.data.parts;

import com.libtowns.GlobalConstants;
import java.io.Serializable;

/**
 *
 * @author rkriebel
 */
public class Townie implements Serializable {

    private byte X = -1;  // On what tile townie is.
    private byte Y = -1;  //
    private byte subX = -1; //position on tileX;
    private byte subY = -1; //position on tileY;
    private byte goal_X = -1;
    private byte goal_Y = -1;
    private TownieClass tclass = TownieClass.NONE;
    private TownieState tstate = TownieState.UNASSIGNED;
    private int amount = 0;
    private ResourceType res = null;
    //
    private Cell origin = null;
    private Cell target = null;
    private int amount_to_target = 0;
    private ResourceType resource_to_target = null;
    private int amount_to_origin = 0;
    private ResourceType resource_to_origin = null;
    private int timer = 0;
    private int dir;

    public int getTimer() {
        return timer;
    }

    public void setTimer(int timer) {
        this.timer = timer;
    }

    public void decreaseTimer() {
        this.timer--;
    }

    public byte getX() {
        return X;
    }

    public byte getY() {
        return Y;
    }

    public void setX(byte X) {
        this.X = X;
    }

    public void setY(byte Y) {
        this.Y = Y;
    }

    public byte getPosX() {
        return (byte) (X + Math.ceil(subX / 100f));
    }

    public byte getPosY() {
        return (byte) (Y + Math.ceil(subY / 100f));
    }

    public byte getSubX() {
        return subX;
    }

    public byte getSubY() {
        return subY;
    }

    public byte getGoal_X() {
        return goal_X;
    }

    public byte getGoal_Y() {
        return goal_Y;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getAmount_to_origin() {
        return amount_to_origin;
    }

    public void setAmount_to_origin(int amount_to_base) {
        this.amount_to_origin = amount_to_base;
    }

    public int getAmount_to_target() {
        return amount_to_target;
    }

    public void setAmount_to_target(int amount_to_target) {
        this.amount_to_target = amount_to_target;
    }

    public Cell getOrigin() {
        return origin;
    }

    public void setOrigin(Cell base) {
        this.origin = base;
    }

    public ResourceType getResource_to_origin() {
        return resource_to_origin;
    }

    public void setResource_to_origin(ResourceType resource_to_origin) {
        this.resource_to_origin = resource_to_origin;
    }

    public ResourceType getResource_to_target() {
        return resource_to_target;
    }

    public void setResource_to_target(ResourceType resource_to_target) {
        this.resource_to_target = resource_to_target;
    }

    public Cell getTarget() {
        return target;
    }

    public void setTarget(Cell target) {
        this.target = target;
    }

    public TownieState getTstate() {
        return tstate;
    }

    public void setTstate(TownieState tstate) {
        this.tstate = tstate;
    }

    public ResourceType getRes() {
        return res;
    }

    public void setRes(ResourceType res) {
        this.res = res;
    }

    public TownieClass getTclass() {
        return tclass;
    }

    public void setTclass(TownieClass tclass) {
        this.tclass = tclass;
    }

    public void disable() {

        if (this.tclass == TownieClass.CARRIER) {
            getTarget().setTownieWorking(false);
        } else if (this.tclass == TownieClass.WORKER) {
            getOrigin().setTownieWorking(false);
        }

        X = -1;
        Y = -1;
        subX = -50;
        subY = -50;
        goal_X = -10;
        goal_Y = -10;
        tclass = TownieClass.NONE;
        tstate = TownieState.UNASSIGNED;
        amount = 0;
        res = null;
        origin = null;
        target = null;
        amount_to_target = 0;
        resource_to_target = null;
        amount_to_origin = 0;
        resource_to_origin = null;
    }

    public void setPos(Cell cell) {
//        Core.i().putMessage(MessageType.DEBUG,"Townie pos set: " + tile.getX() + " " + tile.getY());
        this.X = (byte) cell.getX();
        this.Y = (byte) cell.getY();
        this.subX = 0;
        this.subY = 0;
    }

    public boolean isOnTarget() {
//        Core.i().putMessage(MessageType.DEBUG,"Townie pos/target: "
//                + this.X + "." + this.subX + " , " + this.Y + "." + this.subY
//                + " / " + this.target_X + " , " + this.target_Y);
        return this.goal_X == this.X && this.goal_Y == this.Y && this.subX == 0 && this.subY == 0;
    }
    
    public void setDir(int dir){
        this.dir = dir;
    }
    
    public int getDir(){
        return this.dir;
    }

    public void moveTo(int dir) {
        this.dir = dir;
        switch (dir) {
            case 0:
                this.subX++;
                break;
            case 1:
                this.subY++;
                break;
            case 2:
                this.subX--;
                break;
            case 3:
                this.subY--;
                break;
            default:
                break;
        }
        recalculate();
    }

    private void recalculate() {
        if (this.subX < 0) {
            subX = (byte) (GlobalConstants.cellsize + subX);
            this.X--;
        }
        if (this.subY < 0) {
            subY = (byte) (GlobalConstants.cellsize + subY);
            this.Y--;
        }

        if (this.subX >= GlobalConstants.cellsize) {
            subX = (byte) (subX - GlobalConstants.cellsize);
            this.X++;
        }
        if (this.subY >= GlobalConstants.cellsize) {
            subY = (byte) (subY - GlobalConstants.cellsize);
            this.Y++;
        }
    }

    public void setGoalPos(Cell cell) {
        this.goal_X = cell.getX();
        this.goal_Y = cell.getY();
    }
}
