package com.libtowns.data.parts;

import com.libtowns.data.parts.ResourceType;
import java.io.Serializable;

/**
 *
 * @author rkriebel
 */
public class StockSlot implements Serializable {

    private final ResourceType type;
    private int amount;

    public StockSlot(ResourceType type, int amount) {
        this.type = type;
        this.amount = amount;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public ResourceType getType() {
        return type;
    }

    public void addAmount(int amount) {
        this.amount = this.amount + amount;
    }

    public void decAmount(int amount) {
        this.amount = this.amount - amount;
    }
}
